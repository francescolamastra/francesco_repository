angular.module('app',[])
.constant('API_KEY', '&APPID=699c7034b739d241bb9de07202c08932')
.constant('URL_MAP', 'http://maps.googleapis.com/maps/api/staticmap?center=')
.constant('URL', 'http://api.openweathermap.org/data/2.5/weather?q=')
.constant('API_KEY_MAPS', '&key=AIzaSyD-adbzGKwP7CCC36Vo2G0_Ff9scOETOrM')
.component('home', {
	templateUrl:'views/home.html',
	controller: function($http){
		  var ctrl = this;
           ctrl.$onInit = function(){           
		   $http.get('json/regioni.json').then(function(response){
		       
		       ctrl.regioni = response.data;
		       console.log(ctrl.regioni);
		   });
        
           };
		   ctrl.regione = '';
		   ctrl.updateRegione = function(reg){
		       console.log('Regione Scelta', reg);
		        ctrl.regione = reg;
		    
		   };
		
	}
})
/* creo component regioni che riceve in input le regioni ed ha in output un riferimento(onRadioClick) alla funzione esterna che mi aggiorna il valore
della regione scelta  */
.component('regioni',{
     bindings:{
         regioni:'<',
         onRadioClick:'&'
     },
     templateUrl:'template/templateRegioni.html',
     /* all'interno del controller ho la funzione che verrà richiamata al click dell'input radio che riceve come parametro la regione scelta e richiama 
     la funzione di callback esterna al componente tramite il suo riferimento che abbiamo in bindings(onRadioClick) passandogli come output il parametro tramite 
     key-value{$reg:reg} dove la key ha prefisso $ x identificare che è un valore di output al quale è assegnato il parametro ricevuto dal radio */
     controller: function(){
         var ctrl = this;
         ctrl.regHandler = function(reg){             
             ctrl.onRadioClick({$reg:reg});
         };
     }
})
.component('province',{
    bindings:{
        regione: '<'
    },
    templateUrl:'template/templateProvince.html',
    controller: function($http,URL,API_KEY){
        var ctrl =this;
        ctrl.$onInit = function(){  
        ctrl.provincia = {
            coord: { lat:37.29  ,
                     lon:15.4 }         
        };      
        $http.get('json/provinceJson/provinceSicilia.json').then(function(response){
         ctrl.sicilia = response.data;
         console.log(ctrl.sicilia);
        });
        $http.get('json/provinceJson/provinceLombardia.json').then(function(response){
         ctrl.lombardia = response.data;
         console.log(ctrl.lombardia);
        });
        $http.get('json/provinceJson/provinceCampania.json').then(function(response){
         ctrl.campania = response.data;
         console.log(ctrl.campania);
        });
       
        };
         ctrl.visualizzaProvincia = function(nome){            
            $http.get(URL + nome + API_KEY).then(function(response){
                ctrl.provincia = response.data;
            })
        };
        
        
    }
})
.component('map',{
    bindings:{
        provincia:'<'
    },
    templateUrl: 'template/templateMap.html',
    controller: function(URL_MAP,API_KEY_MAPS){
        var ctrl = this;
        console.log(ctrl);
        ctrl.$onInit = function(){
            /*ctrl.img = 'http://maps.googleapis.com/maps/api/staticmap?center=38.12,13.36&zoom=7&size=200x100&key=AIzaSyD-adbzGKwP7CCC36Vo2G0_Ff9scOETOrM';*/
            ctrl.visualizza = false;
            ctrl.img = URL_MAP;             
            ctrl.img += ctrl.provincia.coord.lat + ",";
            ctrl.img += ctrl.provincia.coord.lon;
            ctrl.img += "&zoom=8&size=300x150";
            ctrl.img += API_KEY_MAPS;  
        };
        
        
/*<img ng-src="{{$ctrl.img}}"/>*/
    
    ctrl.$onChanges = function(obj){
        ctrl.newValue = obj.provincia.currentValue; 
            ctrl.img = URL_MAP;             
            ctrl.img += ctrl.newValue.coord.lat + ",";
            ctrl.img += ctrl.newValue.coord.lon;
            ctrl.img += "&zoom=8&size=300x150";
            ctrl.img += API_KEY_MAPS; 
            ctrl.visualizza = true; 
    }


}
})