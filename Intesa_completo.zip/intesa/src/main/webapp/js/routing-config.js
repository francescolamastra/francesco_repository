(function(angular){
	'use strict';
	angular.module('appModule')
	.config(function($stateProvider, $urlRouterProvider) {
		$urlRouterProvider.otherwise("/");
		$stateProvider
		.state('home', {
			url: '/',
			templateUrl: 'templates/home.html',
			controller: 'indexCtrl'
		})
		.state('gestioneCodici', {
			url: '/gestionecodici/:ndg',
			templateUrl: 'templates/gestioneCodici.html',
			controller: 'gestioneCodiciControparteCtrl as ctrl'
		})
		.state('gestdaticontroparte', {
			url: '/gestdaticontroparte/',
			templateUrl: 'templates/gestioneDatiControparte.html',
			controller: 'gestioneDatiControparteCtrl as ctrl'
		})
		.state('espContenutoInfoRapporto', {
                url: '/gestioneEspansioneInformativaControparte?azienda&ndg',
                component: 'espContenutoInfoRapportoCmp',
                resolve: {        
                    azienda: function ($stateParams) { 
                    	console.log('Funzione che risolve azienda selezionata al cambio view: Azienda Id: ', $stateParams.azienda);
                    	return $stateParams.azienda; 
                    	},
                    ndg: function ($stateParams) { 
                    	console.log('Funzione che risolve ndg al cambio view: NDG ID: ', $stateParams.ndg);
                    	return $stateParams.ndg;
                    	}                 
                }
            })
	});
})(window.angular);