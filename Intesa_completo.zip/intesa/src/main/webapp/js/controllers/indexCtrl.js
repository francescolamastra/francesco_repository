(function(angular){
	'use strict';
	
	angular.module('appModule')
	.controller('indexCtrl', ['$uibModal','$uibModalStack', function($uibModal, $uibModalStack){
		var ctrl = this;
		$uibModalStack.dismissAll();
		ctrl.servizi = [
            {
            	"name":"Gestione Codici Della Controparte",
            	"link":"gestioneCodici"
            },
            {
            	"name":"Gestione Dati Della Controparte",
            	"link":"gestdaticontroparte"
            },
            {
            	"name":"Gestione Espansione Informativa",
            	"link":"espContenutoInfoRapporto"
            },
            {
            	"name":"Gestione Settorizzazione",
            	"link":""
            }
        ];
		ctrl.selectedServizio =	[{
			"name":null,
			"link":null
		}];
		ctrl.selectServizio = function (servName, servLink) {
			ctrl.selectedServizio.name = servName;
			ctrl.selectedServizio.link = servLink;
		};
		ctrl.openModal = function(selected) {
			var modalInstance = $uibModal.open({
				templateUrl: 'templates/modals/initialModal.html',
				controller: 'initialModalCtrl as vm',
				backdrop: 'static',
				keyboard: false,
                size: 'sm',
                resolve: {
                	modalSelected: function() {
                		return selected
                	}
                }
			})
		};
	}])
})(window.angular);