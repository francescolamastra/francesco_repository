(function(angular) {
	'use strict';
	
	angular.module('appModule')
	.controller('datiModalCreaCtrl', ['$uibModalInstance', '$http', 'modalTipoDato',
	                                  function($uibModalInstance, $http, modalTipoDato){
		var vm = this;
		 vm.close = function () {
	            $uibModalInstance.close();
	          };
	       vm.tipoDato = modalTipoDato;
	       
	       $http.get('http://localhost:8080/intesa/gestdaticontroparte').
	       	then (function(response){
	    	   vm.rows = response.data;
	       });
	       
	       vm.nuovo={
	 			  datoV: null,
	 			  dataRiferimento: null,
	 			  noteVarie: null
	 			  };
	       
	      
				  
				  vm.nuovoRow = function() {
					  vm.insert = {
							  "tipoDato" : "DA" + vm.nuovo.datoV,
							  "dataRiferimento" : vm.nuovo.dataRiferimento,
							  "noteVarie" : vm.nuovo.noteVarie,
							  "descrizione" : "Dati Vari Controparte" + vm.nuovo.datoV,
							  "dataCensimento" : "2016-08-10",
							  "dataOra" : "2016-08-10",
							  "idndg_dati" : 2
							  };
					  
					    $http.post('http://localhost:8080/intesa/gestdaticontroparte',  vm.insert ).then(function(success){
					    	console.log('OK');
					    }, function(error){
					    	console.log('KO');
					    });
					    $uibModalInstance.close();
					};
			  }
			
	])
	
})(window.angular);