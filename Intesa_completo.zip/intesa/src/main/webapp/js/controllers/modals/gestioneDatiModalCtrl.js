(function(angular) {
	'use strict';
	angular.module('appModule')
	.controller('datiModalDettaglioCtrl', ['$uibModalInstance', '$uibModal', 'modalSelectedRow', '$http', '$state',
	                                         function($uibModalInstance, $uibModal, modalSelectedRow, $http, $state){
		var vm = this; 
		
		
		vm.selectedRow = modalSelectedRow;
		
		vm.openCrea = function(tipoDato){
			var modalInstance = $uibModal.open({
				templateUrl: 'templates/modals/dettagliDatiControparte/creaDato.html',
	            backdrop : 'static',
	            keyboard : false,
	            controller: 'datiModalCreaCtrl as vm',
	            size : 'sm',
	            resolve: {
	            	modalTipoDato : function(){
	            		return tipoDato;
	            	}
	            }            	
			});
			$uibModalInstance.close();
		};
		
		vm.aggiornato = {
				 tipoDato: vm.selectedRow.tipoDato,
				 datoV:  vm.selectedRow.tipoDato,
	 			 dataRiferimento: new Date(vm.selectedRow.dataRiferimento),
				 noteVarie : vm.selectedRow.noteVarie
		};
		
		vm.updateRow = function() {
			console.log("Dentro aggiorna: ", vm.selectedRow.progressivo);
			  vm.insert = {
					  "progressivo" : vm.selectedRow.progressivo,
					  "tipoDato" : vm.aggiornato.datoV,
					  "dataRiferimento" : vm.aggiornato.dataRiferimento,
					  "noteVarie" : vm.aggiornato.noteVarie,
					  "dataOra" : vm.selectedRow.dataOra,
					  "dataCensimento" : vm.selectedRow.dataCensimento,
					  "descrizione" : "Dati Vari Controparte 0" + vm.aggiornato.datoV,
					  "idndg_dati": vm.selectedRow.idndg_dati
					  };
			  
			    $http.put('http://localhost:8080/intesa/gestdaticontroparte',  vm.insert ).then(function(success){
			    	console.log('OK');
			    	$state.reload('gestdaticontroparte');
			    }, function(error){
			    	console.log('KO');
			    });
			    $uibModalInstance.close();
			};
		
		vm.close = function () {
        	$uibModalInstance.close();
        };
        
        vm.deleteRow = function(iditem){
            console.log('Dentro funzione Elimina ComponentDETTAGLIO, Id da eliminare : ',iditem );               
            $http.delete('http://localhost:8080/intesa/gestdaticontroparte/' + iditem).then(function (success) {
                alert('Record Cancellato con successo');
                console.log('OK');
                $state.reload('gestdaticontroparte');
            }, function (error) {
                alert('Attenzione Record Non Cancellato con successo!!!')
                console.log('KO');
            });

            vm.close();    
        };
        
	}])
	
	.controller('datiModalCreaCtrl', ['$uibModalInstance', '$http', 'modalTipoDato', '$state',
	                                  function($uibModalInstance, $http, modalTipoDato, $state){
		var vm = this;
		 vm.close = function () {
	            $uibModalInstance.close();
	          };
	       vm.tipoDato = modalTipoDato;
	       
	       vm.nuovo={
	 			  datoV: null,
	 			  dataRiferimento: null,
	 			  noteVarie: null
	 			  };
	       
	      
				  
				  vm.nuovoRow = function() {
					  vm.insert = {
							  "tipoDato" : vm.nuovo.datoV,
							  "dataRiferimento" : vm.nuovo.dataRiferimento,
							  "noteVarie" : vm.nuovo.noteVarie,
							  "descrizione" : "Dati Vari Controparte 0" + vm.nuovo.datoV,
							  "dataCensimento" : "2016-08-10",
							  "dataOra" : "2016-08-10",
							  "idndg_dati" : 2
							  };
					  
					    $http.post('http://localhost:8080/intesa/gestdaticontroparte',  vm.insert ).then(function(success){
					    	console.log('OK');
					    	$state.reload('gestdaticontroparte');
					    }, function(error){
					    	console.log('KO');
					    });
					    $uibModalInstance.close();
					};
			  }
			
	])
	
})(window.angular);