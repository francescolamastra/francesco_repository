(function(angular){
	'use strict';
	angular.module('appModule')
	.controller('codiciModalDettaglioCtrl', ['$uibModalInstance','modalSelectedRow',
	                                         function($uibModalInstance, modalSelectedRow){
		var vm = this;
		vm.selectedRow = modalSelectedRow;
		vm.close = function () {
        	$uibModalInstance.close();
        };
	}])
	.controller('codiciModalNuovoCtrl', ['$uibModalInstance', '$http', function($uibModalInstance, $http){
		var vm = this;
		vm.nuovo = {
			"codice":null,
			"valoreCodice": null,
			"dataRiferimento": null,
			"principaleCodice": null
		};
		vm.newRow = function() {
			vm.nuovo.codice = null;
			vm.nuovo.valoreCodice = null;
			vm.nuovo.dataRiferimento = null;
			vm.nuovo.principaleCodice = null;
			vm.insert = {
		    		"codice":"CV" + vm.nuovo.codice,
		    		"dataRiferimento":vm.nuovo.dataRiferimento,
	            	"valoreCodice": vm.nuovo.valoreCodice,
	            	"descrizione":"Codici Vari Controparte",
	            	"principaleCodice": vm.nuovo.principaleCodice,
	            	"forzatoCodice":"forzatoCodVario" ,
	            	"dataCensimento":"2016-08-10",
					"dataVaOraVa":"2017-02-28",
					"idndg_codici":1
		    };
		    vm.close();
		};
		vm.close = function() {
			$uibModalInstance.close();
			vm.nuovo.codice = null;
			vm.nuovo.valoreCodice = null;
			vm.nuovo.dataRiferimento = null;
			vm.nuovo.principaleCodice = null;
		};
		vm.codici = [
        	{
        		"value":"00",
        		"name":"Codice 0",
        		"desc":"descrizione varia per codice 0"
        	},
        	{
        		"value":"01",
        		"name":"Codice 1",
        		"desc":"descrizione varia per codice 1"
        	},
        	{
        		"value":"02",
        		"name":"Codice 2",
        		"desc":"descrizione varia per codice 2"
        	},
        	{
        		"value":"03",
        		"name":"Codice 3",
        		"desc":"descrizione varia per codice 3"
        	},
        	{
        		"value":"04",
        		"name":"Codice 4",
        		"desc":"descrizione varia per codice 4"
        	},
        	{
        		"value":"05",
        		"name":"Codice 5",
        		"desc":"descrizione varia per codice 5"
        	},
        	{
        		"value":"06",
        		"name":"Codice 6",
        		"desc":"descrizione varia per codice 6"
        	},
        	{
        		"value":"07",
        		"name":"Codice 7",
        		"desc":"descrizione varia per codice 7"
        	},
        	{
        		"value":"08",
        		"name":"Codice 8",
        		"desc":"descrizione varia per codice 8"
        	}
		];
	}])
})(window.angular);