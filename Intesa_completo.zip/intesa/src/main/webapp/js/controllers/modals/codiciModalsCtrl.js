(function(angular){
	'use strict';
	angular.module('appModule')
	.controller('codiciModalDettaglioCtrl', ['$uibModal', '$uibModalInstance','modalSelectedRow', '$http', '$state',
	                                         function($uibModal, $uibModalInstance, modalSelectedRow, $http, $state){
		var vm = this;
		vm.selectedRow = modalSelectedRow;
		vm.close = function () {
        	$uibModalInstance.close();
        };
        vm.openNuovo = function () {
        	vm.close();
            var modalInstance = $uibModal.open({
                templateUrl: 'templates/modals/gestioneCodici/nuovoModal.html',
                controller: 'codiciModalNuovoCtrl as vm',
                backdrop: 'static',
                keyboard: false,
                })
        };
        vm.aggiornato = {
        		"codice":vm.selectedRow.codice,
    			"valoreCodice": vm.selectedRow.valoreCodice,
    			"dataRiferimento": new Date(vm.selectedRow.dataRiferimento),
    			"principaleCodice": vm.selectedRow.principaleCodice
    		};
    	vm.openConfirm = function(action, nuovo, selected) {
			vm.close();
	        var modalInstance = $uibModal.open({
	            templateUrl: 'templates/modals/gestioneCodici/confirmationModal.html',
	            controller: 'confirmationModalCtrl as vm',
	            backdrop: 'static',
	            keyboard: false,
	            resolve: {
	            	modalAction: function() {
	            		return action;
	            	},
	            	modalNuovo: function() {
	            		return nuovo;
	            	},
	            	modalSelectedRow: function() {
	            		return selected
	            	}
	            }
	        });
	    };
	}])
	.controller('codiciModalNuovoCtrl', ['$uibModalInstance', '$uibModal', '$http', 'modalNdg',
	                                     function($uibModalInstance, $uibModal, $http, modalNdg){
		var vm = this;
		vm.ndg = modalNdg;
		vm.nuovo = {
			"codice":null,
			"valoreCodice": null,
			"dataRiferimento": null,
			"principaleCodice": null
		};
		vm.close = function() {
			$uibModalInstance.close();
		};
		vm.codici = [
        	{
        		"value":"00",
        		"name":"Codice 0",
        		"desc":"descrizione varia per codice 0"
        	},
        	{
        		"value":"01",
        		"name":"Codice 1",
        		"desc":"descrizione varia per codice 1"
        	},
        	{
        		"value":"02",
        		"name":"Codice 2",
        		"desc":"descrizione varia per codice 2"
        	},
        	{
        		"value":"03",
        		"name":"Codice 3",
        		"desc":"descrizione varia per codice 3"
        	},
        	{
        		"value":"04",
        		"name":"Codice 4",
        		"desc":"descrizione varia per codice 4"
        	},
        	{
        		"value":"05",
        		"name":"Codice 5",
        		"desc":"descrizione varia per codice 5"
        	},
        	{
        		"value":"06",
        		"name":"Codice 6",
        		"desc":"descrizione varia per codice 6"
        	},
        	{
        		"value":"07",
        		"name":"Codice 7",
        		"desc":"descrizione varia per codice 7"
        	},
        	{
        		"value":"08",
        		"name":"Codice 8",
        		"desc":"descrizione varia per codice 8"
        	}
		];
		vm.openConfirm = function(action, nuovo, selected) {
			vm.close();
	        var modalInstance = $uibModal.open({
	            templateUrl: 'templates/modals/gestioneCodici/confirmationModal.html',
	            controller: 'confirmationModalCtrl as vm',
	            backdrop: 'static',
	            keyboard: false,
	            resolve: {
	            	modalAction: function() {
	            		return action;
	            	},
	            	modalNuovo: function() {
	            		return nuovo;
	            	},
	            	modalSelectedRow: function() {
	            		return selected
	            	}
	            }
	        });
	    };
	}])
	.controller('confirmationModalCtrl', ['$http', '$uibModal', '$uibModalInstance', '$state', 'modalAction', 'modalNuovo', 'modalSelectedRow',
	                                      function($http, $uibModal, $uibModalInstance, $state, modalAction, modalNuovo, modalSelectedRow){
		var vm = this;
		vm.action = modalAction;
		vm.nuovo = modalNuovo;
		vm.selectedRow = modalSelectedRow;
		vm.close = function() {
			$uibModalInstance.close();
			vm.nuovo.codice = null;
			vm.nuovo.valoreCodice = null;
			vm.nuovo.dataRiferimento = null;
			vm.nuovo.principaleCodice = null;
		};
		if (vm.action == "aggiungere") {
			vm.operation = function() {
				vm.insert = {
			    		"codice":vm.nuovo.codice,
			    		"dataRiferimento":vm.nuovo.dataRiferimento,
		            	"valoreCodice": vm.nuovo.valoreCodice,
		            	"descrizione":"Codici Vari Controparte" + vm.nuovo.codice,
		            	"principaleCodice": vm.nuovo.principaleCodice,
		            	"forzatoCodice":"forzatoCodVario" ,
		            	"dataCensimento":"2016-08-10",
						"dataVaOraVa":"2017-02-28",
						"idndg_codici":vm.selectedRow
			    };
				$http.post('http://localhost:8080/intesa/gestionecodici', vm.insert).then(function(success){
					console.log('ok');
					$state.reload('gestioneCodici');
				}, function(error){
					console.log('ko')
				});
			    vm.close();
			};
			vm.returned = function () {
	        	vm.close();
	            var modalInstance = $uibModal.open({
	                templateUrl: 'templates/modals/gestioneCodici/nuovoModal.html',
	                controller: 'codiciModalNuovoCtrl as vm',
	                backdrop: 'static',
	                keyboard: false
	                })
	        };
		} else if (vm.action == 'eliminare') {
			vm.operation = function(){
	            console.log('Dentro funzione Elimina ComponentDETTAGLIO, Id da eliminare : ',vm.selectedRow.idGestioneCodiciControparte );               
	            $http.delete('http://localhost:8080/intesa/gestionecodici/' + vm.selectedRow.idGestioneCodiciControparte).then(function (success) {
	                alert('Record Cancellato con successo');
	                console.log('OK');
	                $state.reload('gestioneCodici');
	            }, function (error) {
	                alert('Attenzione Record Non Cancellato con successo!!!')
	                console.log('KO');
	            });
	            vm.close();
	        };
	        vm.returned = function(selectedRow) {
	    		vm.close();
	    		var modalInstance = $uibModal.open({
	                templateUrl: 'templates/modals/gestioneCodici/dettaglioModal.html',
	                controller: 'codiciModalDettaglioCtrl as vm',
	                backdrop: 'static',
	                keyboard: false,
	                resolve: {
	                	modalSelectedRow: function() {
	                		return selectedRow;
	                	} 
	                }
	            });
	    	}
		} else if (vm.action == 'aggiornare') {
			vm.operation = function() {
	        	console.log('Dentro funzione Aggiorna ComponentDETTAGLIO, Id da aggiornare : ',vm.selectedRow.idGestioneCodiciControparte );  
	        	vm.insert = {
	        			"idGestioneCodiciControparte":vm.selectedRow.idGestioneCodiciControparte,
	        			"codice": vm.nuovo.codice,
			    		"dataRiferimento":vm.nuovo.dataRiferimento,
		            	"valoreCodice": vm.nuovo.valoreCodice,
		            	"descrizione":"Codici Vari Controparte" + vm.nuovo.codice,
		            	"principaleCodice": vm.nuovo.principaleCodice,
		            	"forzatoCodice":"forzatoCodVario" ,
		            	"dataCensimento":"2016-08-10",
						"dataVaOraVa":"2017-02-28",
						"idndg_codici":vm.selectedRow.idndg_codici
			    };
	        	$http.put('http://localhost:8080/intesa/gestionecodici', vm.insert).then(function (success) {
	                alert('Record Aggiornato con successo');
	                console.log('OK');
	                $state.reload('gestioneCodici');
	        	}, function (error) {
	                alert('Attenzione Record Non Aggiornato con successo!!!')
	                console.log('KO');
	            });
	            vm.close()
	    	};
	    	vm.returned = function(selectedRow) {
	    		vm.close();
	    		var modalInstance = $uibModal.open({
	                templateUrl: 'templates/modals/gestioneCodici/dettaglioModal.html',
	                controller: 'codiciModalDettaglioCtrl as vm',
	                backdrop: 'static',
	                keyboard: false,
	                resolve: {
	                	modalSelectedRow: function() {
	                		return selectedRow;
	                	} 
	                }
	            });
	    	}
		}
	}])
})(window.angular);