angular.module('appModule')
.controller('gestioneCodiciControparteCtrl', ['$http', '$uibModal', '$stateParams',
                                              function($http, $uibModal, $stateParams) {
	var ctrl = this;
	ctrl.ndg = $stateParams.ndg;
    $http.get('http://localhost:8080/intesa/gestionecodici/'+ctrl.ndg).
        then(function(response) {
            ctrl.rows = response.data;
        });
    ctrl.quantity = 10;
	ctrl.entries = [
		{
			"number":10
		},
		{
			"number":25
		},
		{
			"number":50
		},
		{
			"number":100
		}
	];
	ctrl.selectRow = function (row) {
		ctrl.selectedRow = row
	};
	ctrl.openDettaglio = function (selectedRow) {
        var modalInstance = $uibModal.open({
            templateUrl: 'templates/modals/gestioneCodici/dettaglioModal.html',
            controller: 'codiciModalDettaglioCtrl as vm',
            backdrop: 'static',
            keyboard: false,
            resolve: {
            	modalSelectedRow: function() {
            		return selectedRow;
            	}
            }
        });
    };
    ctrl.openNuovo = function (ndg) {
        var modalInstance = $uibModal.open({
            templateUrl: 'templates/modals/gestioneCodici/nuovoModal.html',
            controller: 'codiciModalNuovoCtrl as vm',
            backdrop: 'static',
            keyboard: false,
            resolve: {
            	modalNdg: function() {
            		return ndg
            	}
            }
            })
        };
}]);