package it.fides.intesa.model;

import java.io.Serializable;

public class Banca {
	private int idbanca;
	private String nomeBanca;
	
	public int getIdbanca() {
		return idbanca;
	}
	public void setIdbanca(int idbanca) {
		this.idbanca = idbanca;
	}
	public String getNomeBanca() {
		return nomeBanca;
	}
	public void setNomeBanca(String nomeBanca) {
		this.nomeBanca = nomeBanca;
	}
}
