package it.fides.intesa.dao.namedParameter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import it.fides.intesa.dao.GestioneEspansioneInformativaDao;
import it.fides.intesa.dao.GestioneEspansioneInformativaDelRapportoDAO;
import it.fides.intesa.mapper.GestEspInfDelRappMapper;
import it.fides.intesa.mapper.GestEspInfMapper;
import it.fides.intesa.model.GestioneEspansioneInformativa;
import it.fides.intesa.model.GestioneEspansioneInformativaDelRapporto;
import it.fides.intesa.model.GestioneSettorizzazione;

@Component
public class JdbcGestioneEspansioneInformativaDelRapportoDAO implements GestioneEspansioneInformativaDelRapportoDAO{
	
	private NamedParameterJdbcTemplate jdbcTemplateObject;
	
	public void setDataSource(DataSource dataSource) {
        this.jdbcTemplateObject = new NamedParameterJdbcTemplate(dataSource);
    }

	public void create(GestioneEspansioneInformativaDelRapporto gestioneEspansioneInformativaDelRapporto) {
		String SQL1 = "insert into gestioneespansioneinformativadelrapporto (  codiceDato, descrizioneCodice, valoreDato, descrizioneValoreDato, dataCensimento, dataOra,idndg_geidr) "
				+ "values ( :codiceDato,:descrizioneCodice,:valoreDato,:descrizioneValoreDato,  :dataCensimento, :dataOra,:idndg_geidr)";
		
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneEspansioneInformativaDelRapporto);
        // Esegue la query passandogli anche i valori effettivi da inserire:
        jdbcTemplateObject.update(SQL1, namedParameters);
	}

	public GestioneEspansioneInformativaDelRapporto read(int idGestEspInfDelRapp) {
		final String SQL = "SELECT * FROM gestioneespansioneinformativadelrapporto WHERE idGestEspInfDelRapp = :idGestEspInfDelRapp";

		SqlParameterSource namedParameters = new MapSqlParameterSource("idGestEspInfDelRapp", idGestEspInfDelRapp);

		return jdbcTemplateObject.queryForObject(SQL, namedParameters, new GestioneEspansioneInformativaDelRapportoRowMapper());
	}
	
private static final class GestioneEspansioneInformativaDelRapportoRowMapper implements RowMapper<GestioneEspansioneInformativaDelRapporto> {
		
		public GestioneEspansioneInformativaDelRapporto mapRow(ResultSet rs, int rowNum) throws SQLException {
			GestioneEspansioneInformativaDelRapporto geidr = new GestioneEspansioneInformativaDelRapporto();
			geidr.setIdGestEspInfDelRapp(rs.getInt("idGestEspInfDelRapp"));
			geidr.setCodiceDato(rs.getString("codiceDato"));	
			geidr.setDescrizioneCodice(rs.getString("descrizioneCodice"));
			geidr.setValoreDato(rs.getString("valoreDato"));
			geidr.setDescrizioneValoreDato(rs.getString("descrizioneValoreDato"));
			geidr.setDataCensimento(rs.getDate("dataCensimento"));
			geidr.setDataOra(rs.getDate("dataOra"));
			geidr.setIdndg_geidr(rs.getInt("idndg_geidr"));
			
			return geidr;
		}
	}
	
	public void update(GestioneEspansioneInformativaDelRapporto gestioneEspansioneInformativaDelRapporto) {
		final String SQL = "UPDATE gestioneespansioneinformativadelrapporto SET " + "codiceDato = :codiceDato, descrizioneCodice = :descrizioneCodice, "
				+ "valoreDato = :valoreDato, descrizioneValoreDato = :descrizioneValoreDato, dataCensimento = :dataCensimento, "
				+ "dataOra = :dataOra, idndg_geidr = :idndg_geidr "
				+ "WHERE idGestEspInfDelRapp = :idGestEspInfDelRapp";

		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneEspansioneInformativaDelRapporto);

		jdbcTemplateObject.update(SQL, namedParameters);

	}

	public List<GestioneEspansioneInformativaDelRapporto> selectAll() {
		String SQL = "select * from gestioneespansioneinformativadelrapporto";

		List<GestioneEspansioneInformativaDelRapporto> gestEspInfDelRapp = jdbcTemplateObject.query(SQL, new GestEspInfDelRappMapper());
		return gestEspInfDelRapp;
	}

	public void delete(int idGestEspInfDelRapp) {
		final String SQL = "DELETE FROM gestioneespansioneinformativadelrapporto WHERE idGestEspInfDelRapp = :idGestEspInfDelRapp";

		SqlParameterSource namedParameters = new MapSqlParameterSource("idGestEspInfDelRapp",
				idGestEspInfDelRapp);

		jdbcTemplateObject.update(SQL, namedParameters);

		System.out.println(String.format("Record ID=%d eliminato", idGestEspInfDelRapp));
	}

}
