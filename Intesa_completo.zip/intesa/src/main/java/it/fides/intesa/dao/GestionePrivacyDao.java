package it.fides.intesa.dao;

import javax.sql.DataSource;

import it.fides.intesa.model.GestionePrivacy;

public interface GestionePrivacyDao {

	public void setDataSource(DataSource ds);
	
	//metodi CRUD
	//crea
	public void create(GestionePrivacy gestionePrivacy);
	
	//leggi
	public GestionePrivacy read(int id_gestprivacy);
	
	//Aggiorna
	public void update(GestionePrivacy gestionePrivacy);
	
	//Elimina
	public void delete(int id_gestprivacy);
}
