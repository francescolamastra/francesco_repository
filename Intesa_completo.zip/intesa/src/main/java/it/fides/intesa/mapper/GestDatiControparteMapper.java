package it.fides.intesa.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import it.fides.intesa.model.GestioneDatiDellaControparte;

public class GestDatiControparteMapper implements RowMapper<GestioneDatiDellaControparte>{
	public GestioneDatiDellaControparte mapRow(ResultSet rs, int rowNum) throws SQLException {
		 
		GestioneDatiDellaControparte gestioneDatiDellaControparte = new GestioneDatiDellaControparte();
		
		
		gestioneDatiDellaControparte.setTipoDato(rs.getString("tipoDato"));
		gestioneDatiDellaControparte.setProgressivo(rs.getInt("progressivo"));
		gestioneDatiDellaControparte.setNoteVarie(rs.getString("noteVarie"));
		gestioneDatiDellaControparte.setDescrizione(rs.getString("descrizione"));
		gestioneDatiDellaControparte.setDataOra(rs.getDate("dataOra"));
		gestioneDatiDellaControparte.setDataRiferimento(rs.getDate("dataRiferimento"));
		gestioneDatiDellaControparte.setDataCensimento(rs.getDate("dataCensimento"));
		gestioneDatiDellaControparte.setIdndg_dati(rs.getInt("idndg_dati"));
		return gestioneDatiDellaControparte;
    }

}
