package it.fides.intesa.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import it.fides.intesa.model.Banca;
import it.fides.intesa.model.GestioneCodiciDellaControparte;

public class BancaMapper implements RowMapper<Banca> {
	public Banca mapRow(ResultSet rs, int rowNum) throws SQLException {
		 
		Banca banca = new Banca();
		
		banca.setIdbanca(rs.getInt("idbanca"));
		banca.setNomeBanca(rs.getString("nomeBanca"));
		return banca;
	}
}
