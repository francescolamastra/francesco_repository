package it.fides.intesa.model;

import java.util.Date;

public class GestioneEspansioneInformativa {
	
	private static final long serialVersionUID = 1L;
	
	private int idGestioneEI;
	private int idndg;
	private int codiceDato;
	private String descrizioneCodici;
	private int valoreDato;
	private String descrizioneValoreDato;
	private Date dataCensimento;
	private Date dataOra;
	public int getIdGestioneEI() {
		return idGestioneEI;
	}
	public void setIdGestioneEI(int idGestioneEI) {
		this.idGestioneEI = idGestioneEI;
	}
	public int getCodiceDato() {
		return codiceDato;
	}
	public void setCodiceDato(int codiceDato) {
		this.codiceDato = codiceDato;
	}
	public String getDescrizioneCodici() {
		return descrizioneCodici;
	}
	public void setDescrizioneCodici(String descrizioneCodici) {
		this.descrizioneCodici = descrizioneCodici;
	}
	public int getValoreDato() {
		return valoreDato;
	}
	public void setValoreDato(int valoreDato) {
		this.valoreDato = valoreDato;
	}
	public String getDescrizioneValoreDato() {
		return descrizioneValoreDato;
	}
	public void setDescrizioneValoreDato(String descrizioneValoreDato) {
		this.descrizioneValoreDato = descrizioneValoreDato;
	}
	public Date getDataCensimento() {
		return dataCensimento;
	}
	public void setDataCensimento(Date dataCensimento) {
		this.dataCensimento = dataCensimento;
	}
	public Date getDataOra() {
		return dataOra;
	}
	public void setDataOra(Date dataOra) {
		this.dataOra = dataOra;
	}
	
	public int getIdndg() {
		return idndg;
	}
	public void setIdndg(int idndg) {
		this.idndg = idndg;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	 
}
