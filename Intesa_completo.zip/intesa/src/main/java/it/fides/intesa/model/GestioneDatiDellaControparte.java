package it.fides.intesa.model;

import java.io.Serializable;
import java.util.Date;

public class GestioneDatiDellaControparte implements Serializable {
	
	private String tipoDato;
	private int progressivo;
	private String noteVarie;
	private String descrizione;
	private Date dataOra;
	private Date dataRiferimento;
	private Date dataCensimento;
	private int idndg_dati;
	
	public GestioneDatiDellaControparte(){}
	
	public GestioneDatiDellaControparte(String tipoDato, int progressivo,
			String noteVarie, String descrizione, Date dataOra, Date dataRiferimento, Date dataCensimento, int idndg_dati){
		super();
		
		this.tipoDato = tipoDato;
		this.progressivo = progressivo;
		this.noteVarie = noteVarie;
		this.descrizione = descrizione;
		this.dataOra = dataOra;
		this.dataRiferimento = dataRiferimento;
		this.dataCensimento = dataCensimento;
		this.idndg_dati = idndg_dati;
	}
	

	public String getTipoDato() {
		return tipoDato;
	}
	
	public void setTipoDato(String tipoDato) {
		this.tipoDato = tipoDato;
	}
	
	public int getProgressivo() {
		return progressivo;
	}
	
	public void setProgressivo(int progressivo) {
		this.progressivo = progressivo;
	}
	
	public String getNoteVarie() {
		return noteVarie;
	}
	
	public void setNoteVarie(String noteVarie) {
		this.noteVarie = noteVarie;
	}
	
	public String getDescrizione() {
		return descrizione;
	}
	
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	
	public Date getDataOra() {
		return dataOra;
	}
	
	public void setDataOra(Date sdf) {
		this.dataOra = sdf;
	}
	
	public Date getDataRiferimento() {
		return dataRiferimento;
	}
	
	public void setDataRiferimento(Date dataRiferimento) {
		this.dataRiferimento = dataRiferimento;
	}
	
	public Date getDataCensimento() {
		return dataCensimento;
	}
	
	public void setDataCensimento(Date dataCensimento) {
		this.dataCensimento = dataCensimento;
	}
	
	public int getIdndg_dati() {
		return idndg_dati;
	}
	
	public void setIdndg_dati(int idndg_dati) {
		this.idndg_dati = idndg_dati;
	}
}
