package it.fides.intesa.dao.namedParameter;

import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import it.fides.intesa.dao.GestionePrivacyDao;
import it.fides.intesa.mapper.GestDatiControparteMapper;
import it.fides.intesa.mapper.GestionePrivacyMapper;
import it.fides.intesa.model.GestionePrivacy;

@Component
public class JdbcGestionePrivacyDAO implements GestionePrivacyDao {
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	   
	   
	 public void setDataSource(DataSource dataSource) {
	      this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	   }

	 //crea
	public void create(GestionePrivacy gestionePrivacy) {
		
		final String SQL = "INSERT INTO gestioneprivacy" +
				   "(id_gestprivacy, tipoPrivacy, descrizionePrivacy, consenso, invInformativa, sportelloRif, descrizioneSportelloRif, riferimento, note, linkDocumento, id_ndg_privacy)"+
				   "VALUES " +
				   "(:id_gestprivacy, :tipoPrivacy, :descrizionePrivacy, :consenso, :invInformativa, :sportelloRif, :descrizioneSportelloRif, :riferimento, :note, :linkDocumento, :id_ndg_privacy)";

SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestionePrivacy);

namedParameterJdbcTemplate.update(SQL, namedParameters);
}
	//leggi
	public GestionePrivacy read(int id_gestprivacy) {
		
		final String SQL = "SELECT * FROM gestioneprivacy WHERE id_gestprivacy = :id_gestprivacy";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("id_gestprivacy", id_gestprivacy);
		
		return namedParameterJdbcTemplate.queryForObject(SQL, namedParameters, new GestionePrivacyMapper());
	}

	//modifica
	public void update(GestionePrivacy gestionePrivacy) {
		final String SQL = "UPDATE gestioneprivacy SET" +
				   "id_gestprivacy = :id_gestprivacy, tipoPrivacy= :tipoPrivacy, descrizionePrivacy= :descrizionePrivacy, "
				   + "consenso= :consenso, invInformativa= :invInformativa, sportelloRif= :sportelloRif, "
				   + "descrizioneSportelloRif= :descrizioneSportelloRif, riferimento= :riferimento, "
				   + "note= :note, linkDocumento= :linkDocumento, id_ndg_privacy= :id_ndg_privacy";
		
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestionePrivacy);

		namedParameterJdbcTemplate.update(SQL, namedParameters);
		
	}

	//cancella
	public void delete(int id_gestprivacy) {
		
		final String SQL = "DELETE FROM gestioneprivacy WHERE id_gestprivacy = :id_gestprivacy";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("id_gestprivacy", id_gestprivacy);
		
	}
	 
}
