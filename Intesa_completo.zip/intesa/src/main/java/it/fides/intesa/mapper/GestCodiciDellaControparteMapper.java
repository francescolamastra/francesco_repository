package it.fides.intesa.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import it.fides.intesa.model.GestioneCodiciDellaControparte;

public class GestCodiciDellaControparteMapper implements RowMapper<GestioneCodiciDellaControparte>{
	public GestioneCodiciDellaControparte mapRow(ResultSet rs, int rowNum) throws SQLException {
		 
		GestioneCodiciDellaControparte gestioneCodiciDellaControparte = new GestioneCodiciDellaControparte();
 
		gestioneCodiciDellaControparte.setIdGestioneCodiciControparte(rs.getInt("idGestioneCodiciControparte"));
		gestioneCodiciDellaControparte.setCodice(rs.getInt("codice"));
		gestioneCodiciDellaControparte.setDataRiferimento(rs.getDate("dataRiferimento"));
		gestioneCodiciDellaControparte.setValoreCodice(rs.getInt("valoreCodice"));
		gestioneCodiciDellaControparte.setDescrizione(rs.getString("descrizione"));
		gestioneCodiciDellaControparte.setPrincipaleCodice(rs.getString("principaleCodice"));
		gestioneCodiciDellaControparte.setForzatoCodice(rs.getString("forzatoCodice"));
		gestioneCodiciDellaControparte.setDataCensimento(rs.getDate("dataCensimento"));
		gestioneCodiciDellaControparte.setDataVaOraVa(rs.getDate("dataVaOraVa"));
		gestioneCodiciDellaControparte.setIdndg_codici(rs.getInt("idndg_codici"));
		
		return gestioneCodiciDellaControparte;
	}
}

