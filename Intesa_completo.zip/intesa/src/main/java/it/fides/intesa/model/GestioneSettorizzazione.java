package it.fides.intesa.model;

import java.io.Serializable;
import java.util.Date;
import java.sql.Time;

public class GestioneSettorizzazione implements Serializable {
	private int idGestioneSettorizzazione;
	private String settore;	
	private String descrizione;
	private String valoreSettoreEco;
	private String descrizioneValore;
	private Date dataCensimento;
	private Date dataOra;
	private int idndg_set;
	
	public GestioneSettorizzazione(){}
	
	

	public GestioneSettorizzazione(int idGestioneSettorizzazione, String settore, String descrizione,
			String valoreSettoreEco, String descrizioneValore, Date dataCensimento, Date dataOra, int idndg_set) {
		super();
		this.idGestioneSettorizzazione = idGestioneSettorizzazione;
		this.settore = settore;
		this.descrizione = descrizione;
		this.valoreSettoreEco = valoreSettoreEco;
		this.descrizioneValore = descrizioneValore;
		this.dataCensimento = dataCensimento;
		this.dataOra = dataOra;
		this.idndg_set = idndg_set;
	}



	public int getIdGestioneSettorizzazione() {
		return idGestioneSettorizzazione;
	}

	public void setIdGestioneSettorizzazione(int idGestioneSettorizzazione) {
		this.idGestioneSettorizzazione = idGestioneSettorizzazione;
	}

	public String getSettore() {
		return settore;
	}

	public void setSettore(String settore) {
		this.settore = settore;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public String getValoreSettoreEco() {
		return valoreSettoreEco;
	}

	public void setValoreSettoreEco(String valoreSettoreEco) {
		this.valoreSettoreEco = valoreSettoreEco;
	}

	public String getDescrizioneValore() {
		return descrizioneValore;
	}

	public void setDescrizioneValore(String descrizioneValore) {
		this.descrizioneValore = descrizioneValore;
	}

	public Date getDataCensimento() {
		return dataCensimento;
	}

	public void setDataCensimento(Date dataCensimento) {
		this.dataCensimento = dataCensimento;
	}

	public Date getDataOra() {
		return dataOra;
	}

	public void setDataOra(Date dataOra) {
		this.dataOra = dataOra;
	}

	public int getIdndg_set() {
		return idndg_set;
	}

	public void setIdndg_set(int idndg_set) {
		this.idndg_set = idndg_set;
	}

	@Override
	public String toString() {
		return "GestioneSettorizzazione [idGestioneSettorizzazione=" + idGestioneSettorizzazione + ", settore="
				+ settore + ", descrizione=" + descrizione + ", valoreSettoreEco=" + valoreSettoreEco
				+ ", descrizioneValore=" + descrizioneValore + ", dataCensimento=" + dataCensimento + ", dataOra="
				+ dataOra + ", idndg_set=" + idndg_set + "]";
	}
	
}
