package it.fides.intesa.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import it.fides.intesa.model.GestioneEspansioneInformativa;
import it.fides.intesa.model.GestioneEspansioneInformativaDelRapporto;

public class GestEspInfDelRappMapper implements RowMapper<GestioneEspansioneInformativaDelRapporto>{
	public GestioneEspansioneInformativaDelRapporto mapRow(ResultSet rs, int rowNum) throws SQLException {
		 
		GestioneEspansioneInformativaDelRapporto gestEspInfDelRapp = new GestioneEspansioneInformativaDelRapporto();
 
		gestEspInfDelRapp.setCodiceDato(rs.getString("codiceDato"));
		gestEspInfDelRapp.setValoreDato(rs.getString("valoreDato"));
		gestEspInfDelRapp.setDataCensimento(rs.getDate("dataCensimento"));
		gestEspInfDelRapp.setDataOra(rs.getDate("dataOra"));
		gestEspInfDelRapp.setDescrizioneCodice(rs.getString("descrizioneCodice"));
		gestEspInfDelRapp.setDescrizioneValoreDato(rs.getString("descrizioneValoreDato"));
		gestEspInfDelRapp.setIdGestEspInfDelRapp(rs.getInt("idGestEspInfDelRapp"));
		gestEspInfDelRapp.setIdndg_geidr(rs.getInt("idndg_geidr"));
 
        return gestEspInfDelRapp;
    }

}
