package it.fides.intesa.dao.namedParameter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import it.fides.intesa.dao.GestioneCodiciDellaControparteDao;
import it.fides.intesa.mapper.GestCodiciDellaControparteMapper;
import it.fides.intesa.mapper.GestEspInfMapper;
import it.fides.intesa.model.GestioneCodiciDellaControparte;
import it.fides.intesa.model.GestioneDatiComplementariDellaControparte;
import it.fides.intesa.model.GestioneEspansioneInformativa;

@Component
public class JdbcGestioneCodiciDellaControparteDAO implements GestioneCodiciDellaControparteDao {
	
	private NamedParameterJdbcTemplate jdbcTemplateObject;
	
	

	 //metodi CRUD
		
	 public void setDataSource(DataSource dataSource) {
	      this.jdbcTemplateObject = new NamedParameterJdbcTemplate(dataSource);
	   }
		//leggi
		public GestioneCodiciDellaControparte read(int idGestioneCodiciControparte) {
			
			final String SQL = "SELECT * FROM gestionecodicidellacontroparte WHERE idGestioneCodiciControparte = :idGestioneCodiciControparte";
			
			SqlParameterSource namedParameters = new MapSqlParameterSource("idGestioneCodiciControparte", idGestioneCodiciControparte);
			
			return jdbcTemplateObject.queryForObject(SQL, namedParameters, new GestCodiciDellaControparteMapper());
		}
		
		
		//cancella
		public void delete(int idGestioneCodiciControparte) {
			
			final String SQL = "DELETE FROM gestionecodicidellacontroparte WHERE idGestioneCodiciControparte = :idGestioneCodiciControparte";
			
			SqlParameterSource namedParameters = new MapSqlParameterSource("idGestioneCodiciControparte", idGestioneCodiciControparte);
			
			jdbcTemplateObject.update(SQL, namedParameters);
			
		}

			public void create(GestioneCodiciDellaControparte gestioneCodiciDellaControparte) {
				final String SQL = "INSERT INTO gestionecodicidellacontroparte" +
						"( codice, dataRiferimento, valoreCodice, descrizione, principaleCodice, forzatoCodice, dataCensimento, dataVaOraVa, idndg_codici)" +
						"VALUES " +
						"( :codice, :dataRiferimento, :valoreCodice, :descrizione, :principaleCodice, :forzatoCodice, :dataCensimento, :dataVaOraVa, :idndg_codici)"; 

						SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneCodiciDellaControparte);
	
						jdbcTemplateObject.update(SQL, namedParameters);
				
			}

			public void update(GestioneCodiciDellaControparte gestioneCodiciDellaControparte) {
				final String SQL = "UPDATE gestionecodicidellacontroparte SET"
						   + " codice = :codice, dataRiferimento = :dataRiferimento, valoreCodice = :valoreCodice,"
						   + " descrizione = :descrizione, principaleCodice = :principaleCodice,"
						   + " forzatoCodice = :forzatoCodice, dataCensimento = :dataCensimento,"
						   + " dataVaOraVa = :dataVaOraVa, idndg_codici = :idndg_codici"
						   + " WHERE idGestioneCodiciControparte = :idGestioneCodiciControparte";
				SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneCodiciDellaControparte);
				
				jdbcTemplateObject.update(SQL, namedParameters);
								
			}
			public List<GestioneCodiciDellaControparte> selectAll() {
				String SQL = "select * from gestionecodicidellacontroparte";
				
				List<GestioneCodiciDellaControparte> gestioneCodiciDellaControparte = jdbcTemplateObject.query(SQL, new GestCodiciDellaControparteMapper());
					return gestioneCodiciDellaControparte;
			}
			
			public List<GestioneCodiciDellaControparte> selectAllByNdg(int idndg) { 
				String SQL = "SELECT * FROM gestionecodicidellacontroparte WHERE idndg_codici = :idndg";
				
				SqlParameterSource namedParameters = new MapSqlParameterSource("idndg", idndg);

				return jdbcTemplateObject.query(SQL, namedParameters, new GestCodiciDellaControparteMapper());
			}
	}
