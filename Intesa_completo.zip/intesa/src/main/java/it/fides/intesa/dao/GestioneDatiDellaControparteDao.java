package it.fides.intesa.dao;

import java.util.List;

import javax.sql.DataSource;

import it.fides.intesa.model.GestioneDatiDellaControparte;

public interface GestioneDatiDellaControparteDao {
	
	
	public void setDataSource(DataSource ds);
	
	//metodi CRUD
	//crea
	public void create(GestioneDatiDellaControparte gestioneDatiDellaControparte);
	
	//leggi
	public GestioneDatiDellaControparte read(int progressivo);
	
	//Aggiorna
	public void update(GestioneDatiDellaControparte gestioneDatiDellaControparte);
	
	//Elimina
	public void delete(int progressivo);
	
	//Lista
	public List<GestioneDatiDellaControparte> selectAll();
}
