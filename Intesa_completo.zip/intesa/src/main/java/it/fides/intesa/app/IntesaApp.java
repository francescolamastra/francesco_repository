package it.fides.intesa.app;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.security.auth.message.config.AuthConfigFactory;

import org.apache.catalina.authenticator.jaspic.AuthConfigFactoryImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import it.fides.intesa.dao.namedParameter.JdbcGestioneDatiDellaControparteDAO;
import it.fides.intesa.dao.namedParameter.JdbcGestioneEspansioneInformativaDAO;
import it.fides.intesa.dao.namedParameter.JdbcGestioneEspansioneInformativaDelRapportoDAO;
import it.fides.intesa.dao.namedParameter.JdbcGestionePrivacyDAO;
import it.fides.intesa.model.GestioneDatiDellaControparte;
import it.fides.intesa.model.GestioneEspansioneInformativa;
import it.fides.intesa.model.GestioneEspansioneInformativaDelRapporto;
import it.fides.intesa.model.GestionePrivacy;

@SpringBootApplication
public class IntesaApp {

	public static void main(String[] args) {
		/*ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		JdbcGestioneDatiDellaControparteDAO gestEspInf = (JdbcGestioneDatiDellaControparteDAO) context.getBean("gestDatiControparte");
		Date a = new Date();
		GestioneDatiDellaControparte gestEi = new GestioneDatiDellaControparte();*/
		
		/*List<GestioneEspansioneInformativa> list = gestEspInf.selectAll();
		 
        for (GestioneEspansioneInformativa record : list) {        // e li stampa
            System.out.print("CodiceDato : " + record.getCodiceDato());
            System.out.print(",DescrizioneCodiceDato : " + record.getDescrizioneCodici());
            System.out.print(", DescrizioneValoreDato : " + record.getDescrizioneValoreDato());
            System.out.print(", IdGestioneEI : " + record.getIdGestioneEI());
            System.out.print(", DataOra : " + record.getDataOra());
            System.out.print(", ValoreDato : " + record.getValoreDato());
            System.out.print(", DataCensimento : " + record.getDataCensimento());
            System.out.println(", Idndg : " + record.getIdndg());
        }*/
		
		
		/*SpringApplication.run(IntesaApp.class, args);
        //gestEi.
		gestEi.setDataCensimento(a);
		gestEi.setDataOra(a);
		gestEi.setDataRiferimento(a);
		gestEi.setDescrizione("Maio");
		gestEi.setIdndg_dati(2);
		gestEi.setNoteVarie("Blalalal");
		gestEi.setTipoDato("Da da da");
		
		gestEspInf.create(gestEi);
/* Prova Data e Ora
		Calendar calendario = Calendar.getInstance();
		Date data = calendario.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		System.out.println(sdf.format(data));
*/ 
		
//		//PROVA 
//		JdbcGestionePrivacyDAO gestPrivacy = (JdbcGestionePrivacyDAO) context.getBean("gestPrivacy");
//		GestionePrivacy gestPriv = new GestionePrivacy();
//		
//		gestPriv.setId_gestprivacy(1);
//		gestPriv.setConsenso("si");
//		gestPriv.setDescrizionePrivacy("Molto bella");
//		gestPriv.setDescrizioneSportelloRif("Na merda");
//		gestPriv.setId_ndg_privacy(4);
//		gestPriv.setInvInformativa("C'�");
//		gestPriv.setLinkDocumento("L� cuore");
//		gestPriv.setNote("Cattivone");
//		gestPriv.setRiferimento("po");
//		gestPriv.setSportelloRif("Napule");
//		gestPriv.setTipoPrivacy("poco privata");
//		
//		gestPrivacy.create(gestPriv);
		
//		// PROVA
		//JdbcGestioneEspansioneInformativaDelRapportoDAO gestioneEspansioneInformativaDelRapportoDAO = (JdbcGestioneEspansioneInformativaDelRapportoDAO) context.getBean("gestEspInfDelRapp");
		//GestioneEspansioneInformativaDelRapporto gestioneEspansioneInformativaDelRapporto = new GestioneEspansioneInformativaDelRapporto();
//
//		gestioneEspansioneInformativaDelRapporto.setCodiceDato("codiceDato2");
//		gestioneEspansioneInformativaDelRapporto.setDescrizioneCodice("descrizioneCodice2");
//		gestioneEspansioneInformativaDelRapporto.setValoreDato("valoreDato2");
//		gestioneEspansioneInformativaDelRapporto.setDescrizioneValoreDato("descrizionefgfgfggf");
//		gestioneEspansioneInformativaDelRapporto.setDataCensimento(a);
//		gestioneEspansioneInformativaDelRapporto.setDataOra(a);
//		gestioneEspansioneInformativaDelRapporto.setIdndg_geidr(1);
//		gestioneEspansioneInformativaDelRapporto.setIdGestEspInfDelRapp(2);
//		gestioneEspansioneInformativaDelRapportoDAO.update(gestioneEspansioneInformativaDelRapporto);
		//gestioneEspansioneInformativaDelRapportoDAO.delete(3);
	}

}
