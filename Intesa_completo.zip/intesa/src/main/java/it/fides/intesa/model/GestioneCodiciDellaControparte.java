package it.fides.intesa.model;

import java.io.Serializable;
import java.util.Date;

public class GestioneCodiciDellaControparte implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int idGestioneCodiciControparte;
	private String codice;
	private Date dataRiferimento;
	private int valoreCodice;
	private String descrizione;
	private String principaleCodice;
	private String forzatoCodice;
	private Date dataCensimento;
	private Date dataVaOraVa;
	private int idndg_codici;
	
	public GestioneCodiciDellaControparte() {}
	
	public GestioneCodiciDellaControparte(int idGestioneCodiciControparte, String codice, Date dataRiferimento,
			int valoreCodice, String descrizione, String principaleCodice, String forzatoCodice, Date dataCensimento,
			Date dataVaOraVa, int idndg_codici) {
		super();
		this.idGestioneCodiciControparte = idGestioneCodiciControparte;
		this.codice = codice;
		this.dataRiferimento = dataRiferimento;
		this.valoreCodice = valoreCodice;
		this.descrizione = descrizione;
		this.principaleCodice = principaleCodice;
		this.forzatoCodice = forzatoCodice;
		this.dataCensimento = dataCensimento;
		this.dataVaOraVa = dataVaOraVa;
		this.idndg_codici = idndg_codici;
	}

	public int getIdGestioneCodiciControparte() {
		return idGestioneCodiciControparte;
	}

	public String getCodice() {
		return codice;
	}

	public Date getDataRiferimento() {
		return dataRiferimento;
	}

	public int getValoreCodice() {
		return valoreCodice;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public String getForzatoCodice() {
		return forzatoCodice;
	}

	public Date getDataCensimento() {
		return dataCensimento;
	}

	public Date getDataVaOraVa() {
		return dataVaOraVa;
	}

	public int getIdndg_codici() {
		return idndg_codici;
	}

	public void setIdGestioneCodiciControparte(int idGestioneCodiciControparte) {
		this.idGestioneCodiciControparte = idGestioneCodiciControparte;
	}

	public void setCodice(String codice) {
		this.codice = codice;
	}

	public void setDataRiferimento(Date dataRiferimento) {
		this.dataRiferimento = dataRiferimento;
	}

	public void setValoreCodice(int valoreCodice) {
		this.valoreCodice = valoreCodice;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public void setForzatoCodice(String forzatoCodice) {
		this.forzatoCodice = forzatoCodice;
	}

	public void setDataCensimento(Date dataCensimento) {
		this.dataCensimento = dataCensimento;
	}

	public void setDataVaOraVa(Date dataVaOraVa) {
		this.dataVaOraVa = dataVaOraVa;
	}

	public void setIdndg_codici(int idndg_codici) {
		this.idndg_codici = idndg_codici;
	}

	public String getPrincipaleCodice() {
		return principaleCodice;
	}

	public void setPrincipaleCodice(String principaleCodice) {
		this.principaleCodice = principaleCodice;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	};
	
	

}
