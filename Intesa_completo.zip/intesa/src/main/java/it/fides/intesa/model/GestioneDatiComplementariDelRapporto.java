package it.fides.intesa.model;

public class GestioneDatiComplementariDelRapporto {
	private int idGestDatiComplRapp;
	private String datoComplementare;
	private String descrizioneDato;
	private int valoreCodice;
	private String descrizioneCodice;
	private int id_ndg_dati_comp_rapp;
	
	public int getIdGestDatiComplRapp() {
		return idGestDatiComplRapp;
	}
	
	public void setIdGestDatiComplRapp(int idGestDatiComplRapp) {
		this.idGestDatiComplRapp = idGestDatiComplRapp;
	}
	
	public String getDatoComplementare() {
		return datoComplementare;
	}
	
	public void setDatoComplementare(String datoComplementare) {
		this.datoComplementare = datoComplementare;
	}
	
	public String getDescrizioneDato() {
		return descrizioneDato;
	}
	
	public void setDescrizioneDato(String descrizioneDato) {
		this.descrizioneDato = descrizioneDato;
	}
	
	public int getValoreCodice() {
		return valoreCodice;
	}
	
	public void setValoreCodice(int valoreCodice) {
		this.valoreCodice = valoreCodice;
	}
	
	public String getDescrizioneCodice() {
		return descrizioneCodice;
	}
	
	public void setDescrizioneCodice(String descrizioneCodice) {
		this.descrizioneCodice = descrizioneCodice;
	}
	
	public int getId_ndg_dati_comp_rapp() {
		return id_ndg_dati_comp_rapp;
	}
	
	public void setId_ndg_dati_comp_rapp(int id_ndg_dati_comp_rapp) {
		this.id_ndg_dati_comp_rapp = id_ndg_dati_comp_rapp;
	}
}
