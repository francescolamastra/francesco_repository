package it.fides.intesa.model;

import java.util.Date;

public class GestioneEspansioneInformativaDelRapporto {
	
	private int idGestEspInfDelRapp;	
	private String codiceDato;
	private String descrizioneCodice;
	private String valoreDato;
	private String descrizioneValoreDato;
	private Date dataCensimento;
	private Date dataOra;
	private int idndg_geidr;
	
	public int getIdGestEspInfDelRapp() {
		return idGestEspInfDelRapp;
	}
	public void setIdGestEspInfDelRapp(int idGestEspInfDelRapp) {
		this.idGestEspInfDelRapp = idGestEspInfDelRapp;
	}
	public String getCodiceDato() {
		return codiceDato;
	}
	public void setCodiceDato(String codiceDato) {
		this.codiceDato = codiceDato;
	}
	public String getDescrizioneCodice() {
		return descrizioneCodice;
	}
	public void setDescrizioneCodice(String descrizioneCodice) {
		this.descrizioneCodice = descrizioneCodice;
	}
	public String getValoreDato() {
		return valoreDato;
	}
	public void setValoreDato(String valoreDato) {
		this.valoreDato = valoreDato;
	}
	public String getDescrizioneValoreDato() {
		return descrizioneValoreDato;
	}
	public void setDescrizioneValoreDato(String descrizioneValoreDato) {
		this.descrizioneValoreDato = descrizioneValoreDato;
	}
	public Date getDataCensimento() {
		return dataCensimento;
	}
	public void setDataCensimento(Date dataCensimento) {
		this.dataCensimento = dataCensimento;
	}
	public Date getDataOra() {
		return dataOra;
	}
	public void setDataOra(Date dataOra) {
		this.dataOra = dataOra;
	}
	public int getIdndg_geidr() {
		return idndg_geidr;
	}
	public void setIdndg_geidr(int idndg_geidr) {
		this.idndg_geidr = idndg_geidr;
	}
	
}
