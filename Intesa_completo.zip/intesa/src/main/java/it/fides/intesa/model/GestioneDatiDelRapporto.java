package it.fides.intesa.model;

import java.sql.Date;

public class GestioneDatiDelRapporto {
	private int progressivo;
	private String tipoDato;
	private String descrizione;
	private Date dataRiferimento;
	private String noteVarie;
	private Date dataCensimento;
	private Date dataOra;
	private int id_ndg_rap;
	
	public int getId_ndg_rap() {
		return id_ndg_rap;
	}

	public void setId_ndg_rap(int id_ndg_rap) {
		this.id_ndg_rap = id_ndg_rap;
	}

	public int getProgressivo() {
		return progressivo;
	}
	
	public void setProgressivo(int progressivo) {
		this.progressivo = progressivo;
	}
	
	public String getTipoDato() {
		return tipoDato;
	}
	
	public void setTipoDato(String tipoDato) {
		this.tipoDato = tipoDato;
	}
	
	public String getDescrizione() {
		return descrizione;
	}
	
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	
	public Date getDataRiferimento() {
		return dataRiferimento;
	}
	
	public void setDataRiferimento(Date dataRiferimento) {
		this.dataRiferimento = dataRiferimento;
	}
	
	public String getNoteVarie() {
		return noteVarie;
	}
	
	public void setNoteVarie(String noteVarie) {
		this.noteVarie = noteVarie;
	}
	
	public Date getDataCensimento() {
		return dataCensimento;
	}
	
	public void setDataCensimento(Date dataCensimento) {
		this.dataCensimento = dataCensimento;
	}
	
	public Date getDataOra() {
		return dataOra;
	}
	
	public void setDataOra(Date dataOra) {
		this.dataOra = dataOra;
	}
}
