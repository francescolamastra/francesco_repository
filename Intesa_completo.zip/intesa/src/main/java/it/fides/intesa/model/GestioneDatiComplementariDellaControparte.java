package it.fides.intesa.model;

public class GestioneDatiComplementariDellaControparte {
	private int idGestDatiCompl;
	private int datoComplementare;
	private String descrizioneDato;
	private int valoreCodice;
	private String descrizioneCodice;
	private int id_ndg_dati_complementari;
	
	public int getIdGestDatiCompl() {
		return idGestDatiCompl;
	}
	
	public void setIdGestDatiCompl(int idGestDatiCompl) {
		this.idGestDatiCompl = idGestDatiCompl;
	}
	
	public int getDatoComplementare() {
		return datoComplementare;
	}
	
	public void setDatoComplementare(int datoComplementare) {
		this.datoComplementare = datoComplementare;
	}
	
	public String getDescrizioneDato() {
		return descrizioneDato;
	}
	
	public void setDescrizioneDato(String descrizioneDato) {
		this.descrizioneDato = descrizioneDato;
	}
	
	public int getValoreCodice() {
		return valoreCodice;
	}
	
	public void setValoreCodice(int valoreCodice) {
		this.valoreCodice = valoreCodice;
	}
	
	public String getDescrizioneCodice() {
		return descrizioneCodice;
	}
	
	public void setDescrizioneCodice(String descrizioneCodice) {
		this.descrizioneCodice = descrizioneCodice;
	}
	
	public int getId_ndg_dati_complementari() {
		return id_ndg_dati_complementari;
	}
	
	public void setId_ndg_dati_complementari(int id_ndg_dati_complementari) {
		this.id_ndg_dati_complementari = id_ndg_dati_complementari;
	}	
}
