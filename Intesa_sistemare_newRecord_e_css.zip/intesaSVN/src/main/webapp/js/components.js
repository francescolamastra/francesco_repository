(function(angular) {
	'use strict';
	angular.module("appModule")
	.component('navbar', {
		templateUrl: 'templates/navbar.html',
	})
	.component('greenPanel', {
		templateUrl: 'templates/greenPanel.html'
	})	
    .component('espContenutoInfoRapportoCmp', {
        templateUrl: 'templates/espContenutoInfoRapporto.html',
        bindings: {
            azienda: '<',
            ndg: '<'            
        },
        controller: function ($http,$uibModal) {     	
        	
            var $ctrl = this;         
            $ctrl.$onInit = function(){ 
                 $ctrl.id = '';
                 $ctrl.gestEspInf = {};
                 
                 /*$ctrl.aggiungi = function(gestEspInf){
                     $ctrl.contenuto.push(gestEspInf);
                 };*/
                 $ctrl.elimina = function(idgest){
                	 var exit = true; 
                    console.log('dentro funzione callBack elimina espContenutoInfoRapportoCmp', idgest); 
                                                      
                         angular.forEach($ctrl.contenuto, function(value, key , dettaglio){
                             if (exit){
                              console.log('Dentro forEach', value.idGestioneEI);                        
                                 if(value.idGestioneEI === idgest){
                                    dettaglio.splice(key, 1);
                                    exit = false;
                                 }
                             }
                         })
            };
                 $ctrl.visualizzaRagg = function(id){
                     console.log('DEntro funzione visualizza/nascondi Raggruppamento id da visualizzare/nascondere: ', id);
                     if($ctrl.id===id){
                         $ctrl.id = '';
                     } else {
                     
                     $ctrl.id = id;
                     }
                 };
                 $ctrl.cmpCrea = 'creaDettaglioEspContenutoInf';
                 $http.get('http://localhost:8080/intesa/gestespinf/' + $ctrl.ndg).then(function (response) {  
                              		
            		$ctrl.contenuto = response.data;  
                    console.log('Request al DB per recuperare dati con NDG ', $ctrl.ndg, 'Dati recuperati : ', $ctrl.contenuto);    
                },
                function (error) {
                    alert('Problema con il DB');
                    console.log('KO');
                })             
             
            };  
            $ctrl.aggiungi = function(){                
                  $http.get('http://localhost:8080/intesa/gestespinf/' + $ctrl.ndg).then(function (response) {  
                              		
            		$ctrl.contenuto = response.data;  
                    console.log('Request al DB per recuperare dati con NDG ', $ctrl.ndg, 'Dati recuperati : ', $ctrl.contenuto);    
                },
                function (error) {
                    alert('Problema con il DB');
                    console.log('KO');
                })
                };                              
                      
            $ctrl.openComponentModal = function(cmp,aggiungi){
               var modalInstance = $uibModal.open({
                   animation:true,
                   component:cmp,
                   backdrop:'static',
                   keyboard:false,
                   resolve:{
                       ndg:function(){
                           return $ctrl.ndg;
                       },
                       aggiungi:function(){
                           return aggiungi;
                       }
                   }              
                  })
            } ;     
           
        }
    })

    .component('raggruppDettaglioEspContInfoCmp', {
        templateUrl: 'templates/raggrdettaglioEspContInfo.html',
        bindings: {
            dettaglio: '<',
            ndg: '<',
            onElimina: '&',
            onCreate: '&'
        },
        controller: function ($uibModal) {        
                var $ctrl = this;
                $ctrl.$onInit = function(){  
                $ctrl.aggiungi=function(){
                    console.log('Dentro funzione aggiungi ComponentRaggruppamento: ');
                    $ctrl.onCreate();
                }
                              
                $ctrl.elimina = function(idgest){  
                    console.log('Dentro funzione Elimina ComponentRaggruppamento, Id da eliminare : ',idgest ); 
                    $ctrl.onElimina({$idgest:idgest});                   
                     
                };               
              
                $ctrl.cmpDettaglio = 'dettaglioEspContInfoCmp';
                };
                $ctrl.openComponentModal = function(cmp,dett,elimina,aggiungi,ndg){
                    var modalInstance = $uibModal.open({
                        animation:true,
                        component:cmp,                        
                        keyboard:false,
                        resolve:{ 
                            dett: function(){
                                return dett;
                            } ,
                            elimina:function(){
                                return elimina;
                            },
                            aggiungi: function(){
                                return aggiungi;
                            },
                            ndg:function(){
                                return ndg;
                            }                         
                        }
                    })
                };
               
            $ctrl.annulla = function () {
                 $ctrl.dismiss();
           };

             console.log('Controller raggruppDettaglioEspContInfoCmp', $ctrl);
        }
    })
    .component('dettaglioEspContInfoCmp',{
        templateUrl:'templates/modals/gestEspInf/dettaglioEspContInfoCmpModal.html',
        bindings:{
             resolve:'=',
             close:'&',
             dismiss:'&'
        },
        controller:function($uibModal,$http){
            var $ctrl = this;
            $ctrl.$onInit = function(){
                $ctrl.cmpCrea = 'creaDettaglioEspContenutoInf';
                $ctrl.dett = $ctrl.resolve.dett;
                $ctrl.del = $ctrl.resolve.elimina;
                $ctrl.add = $ctrl.resolve.aggiungi;
                $ctrl.ndg = $ctrl.resolve.ndg;
                $ctrl.reset = {};
                $ctrl.supp = {};
                angular.copy($ctrl.dett, $ctrl.supp);
                console.log('Dentro OnInit DettaglioCmp Var Supporto Copia di Dettaglio', $ctrl.supp);
            }
             $ctrl.aggiorna= function(item){
                console.log('Dentro Funzione Aggiorna: ', item);
                if(angular.equals(item, $ctrl.dett )){
                        alert('Nessun aggiornamento Effettuato');                        
                } else {
                angular.copy(item, $ctrl.dett);                           
                
                $http.put('http://localhost:8080/intesa/gestespinf', item).then(function (success) {
                    alert('Record Aggiornato con successo');
                    console.log('OK');
                }, function (error) {
                    alert('Attenzione Record Non Aggiornato con successo!!!')
                    console.log('KO');
                });
                $ctrl.close();
                }
                

            };
            $ctrl.elimina = function(iditem){
                console.log('Dentro funzione Elimina ComponentDETTAGLIO, Id da eliminare : ',iditem ); 
                /*angular.copy($ctrl.reset,  $ctrl.dett);*/               
                $http.delete('http://localhost:8080/intesa/gestespinf/' + iditem).then(function (success) {
                    alert('Record Cancellato con successo');
                    console.log('OK');
                }, function (error) {
                    alert('Attenzione Record Non Cancellato con successo!!!')
                    console.log('KO');
                })
                
                $ctrl.del(iditem);
                $ctrl.close();    

            };
            $ctrl.openComponentModal = function(cmp,add,ndg){
                    var modalInstance = $uibModal.open({
                        animation:true,
                        component:cmp,  
                        backdrop:'static',
                        keyboard:false,
                        resolve:{
                            add:function(){
                                return add;
                            },
                            ndg:function(){
                                return ndg;
                            }
                        }                     
                    })
                    $ctrl.dismiss();
                };

        }

    })
    .component('creaDettaglioEspContenutoInf',{
         templateUrl:'templates/modals/gestEspInf/creaDettaglioEspContenutoInfModal.html',  
          bindings:{ 
            resolve:'<',           
            close: '&',
            dismiss: '&'
        },     
         controller:function($http){             
             var $ctrl = this; 
             $ctrl.$onInit = function () {
                     $ctrl.ndg = $ctrl.resolve.ndg;  
                     console.log('$ctrl.ndg Dentro $onInit', $ctrl.ndg);
                     $ctrl.aggiungi = $ctrl.resolve.add;                 
                         }; 
             console.log('Dentro Controller modal Crea Dettaglio ', $ctrl);
            
             $ctrl.submit = function (gestEspInf) {
                 console.log('Dentro funzione submit', $ctrl.ndg);
                gestEspInf.idndg = $ctrl.ndg;
                console.log('Oggetto salvato in DB ', gestEspInf);
                $http.post('http://localhost:8080/intesa/gestespinf', gestEspInf).then(function (success) {
                    $ctrl.aggiungi();
                    alert('Record Inserito con successo');
                   
                    console.log('OK');
                }, function (error) {
                    alert('Attenzione Record Non Inserito con successo!!!')
                    console.log('KO');
                });
                $ctrl.close();
                
                
            }
             $ctrl.annulla = function () {
                 $ctrl.dismiss();
           };

         }
    })
	
})(window.angular);