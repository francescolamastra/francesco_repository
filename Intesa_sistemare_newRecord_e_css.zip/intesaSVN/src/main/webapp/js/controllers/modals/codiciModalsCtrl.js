(function(angular){
	'use strict';
	angular.module('appModule')
	.controller('codiciModalDettaglioCtrl', ['$uibModalInstance','modalSelectedRow',
	                                         function($uibModalInstance, modalSelectedRow){
		var vm = this;
		vm.selectedRow = modalSelectedRow;
		vm.close = function () {
        	$uibModalInstance.close();
        };
	}])
	.controller('codiciModalNuovoCtrl', ['$uibModalInstance', '$http', function($uibModalInstance, $http){
		var vm = this;
		vm.nuovo = {
			"codice":null,
			"valoreCodice": null,
			"dataRiferimento": null,
			"principaleCodice": null
		};
		vm.insert = {
	    		"idGestioneCodiciControparte":5,
	    		"codice":"CV" + vm.nuovo.codice,
            	"valoreCodice":vm.nuovo.valoreCodice,
            	"descrizione":"Codici Vari Controparte " + (vm.nuovo.codice),
            	"forzatoCodice":"forzatoCodVario"  + 5,
            	"dataCensimento":"18/09/2016",
				"dataCensimento":"18/09/2016",
				"dataRiferimento":vm.nuovo.dataRiferimento,
				"principaleCodice": vm.nuovo.principaleCodice,
				"dataVaOraVa":"11/08/2016 12:00",
				"idndg_set":1
	    };
		vm.newRow = function() {
		    $http.post('http://localhost:8080/intesa/gestionecodici',  vm.insert ).then(function(success){
		    	console.log('OK');
		    }, function(error){
		    	console.log('KO');
		    });
		};
		vm.close = function() {
			$uibModalInstance.close();
		};
		vm.codici = [
        	{
        		"value":"00",
        		"name":"Codice 0",
        		"desc":"descrizione varia per codice 0"
        	},
        	{
        		"value":"01",
        		"name":"Codice 1",
        		"desc":"descrizione varia per codice 1"
        	},
        	{
        		"value":"02",
        		"name":"Codice 2",
        		"desc":"descrizione varia per codice 2"
        	},
        	{
        		"value":"03",
        		"name":"Codice 3",
        		"desc":"descrizione varia per codice 3"
        	},
        	{
        		"value":"04",
        		"name":"Codice 4",
        		"desc":"descrizione varia per codice 4"
        	},
        	{
        		"value":"05",
        		"name":"Codice 5",
        		"desc":"descrizione varia per codice 5"
        	},
        	{
        		"value":"06",
        		"name":"Codice 6",
        		"desc":"descrizione varia per codice 6"
        	},
        	{
        		"value":"07",
        		"name":"Codice 7",
        		"desc":"descrizione varia per codice 7"
        	},
        	{
        		"value":"08",
        		"name":"Codice 8",
        		"desc":"descrizione varia per codice 8"
        	}
		];
	}])
})(window.angular);