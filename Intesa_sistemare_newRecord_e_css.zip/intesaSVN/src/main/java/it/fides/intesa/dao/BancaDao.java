package it.fides.intesa.dao;

import java.util.List;

import javax.sql.DataSource;

import it.fides.intesa.model.Banca;

public interface BancaDao {
public void setDataSource(DataSource ds);
	
	public List<Banca> read();
}
