package it.fides.intesa.dao;

import javax.sql.DataSource;

import it.fides.intesa.model.GestioneDatiDelRapporto;

public interface GestioneDatiDelRapportoDao {

	public void setDataSource(DataSource ds);
	
	//metodi CRUD
	//crea
	public void create(GestioneDatiDelRapporto gestioneDatiDelRapporto);
	
	//leggi
	public GestioneDatiDelRapporto read(int idGestioneDatiDelRapporto);
	
	//Aggiorna
	public void update(GestioneDatiDelRapporto gestioneDatiDelRapporto);
	
	//Elimina
	public void delete(int idGestioneDatiDelRapporto);
}
