package it.fides.intesa.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import it.fides.intesa.model.GestioneCodiciDellaControparte;

public class GestCodiciDellaControparteMapper implements RowMapper<GestioneCodiciDellaControparte>{
	public GestioneCodiciDellaControparte mapRow(ResultSet rs, int rowNum) throws SQLException {
		 
		GestioneCodiciDellaControparte gestioneCodiciDellaControparte = new GestioneCodiciDellaControparte();
 
		gestioneCodiciDellaControparte.setIdGestioneCodiciControparte(rs.getInt("idGestioneCodiciControparte"));
		gestioneCodiciDellaControparte.setCodice(rs.getString("Codice"));
		gestioneCodiciDellaControparte.setDataRiferimento(rs.getDate("DataRiferimento"));
		gestioneCodiciDellaControparte.setValoreCodice(rs.getInt("ValoreCodice"));
		gestioneCodiciDellaControparte.setDescrizione(rs.getString("Descrizione"));
		gestioneCodiciDellaControparte.setPrincipaleCodice(rs.getString("PrincipaleCodice"));
		gestioneCodiciDellaControparte.setForzatoCodice(rs.getString("ForzatoCodice"));
		gestioneCodiciDellaControparte.setDataCensimento(rs.getDate("DataCensimento"));
		gestioneCodiciDellaControparte.setDataVaOraVa(rs.getTime("DataVa+OraVa"));
		gestioneCodiciDellaControparte.setIdndg_codici(rs.getInt("idndg_codici"));
		
		return gestioneCodiciDellaControparte;
	}
}

