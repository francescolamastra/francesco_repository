package it.fides.intesa.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import it.fides.intesa.model.GestioneDatiDelRapporto;

public class GestDatiRapportoMapper implements RowMapper<GestioneDatiDelRapporto>{
	public GestioneDatiDelRapporto mapRow(ResultSet rs, int rowNum) throws SQLException {
		 
		GestioneDatiDelRapporto gestioneDatiDelRapporto = new GestioneDatiDelRapporto();
 
		gestioneDatiDelRapporto.setProgressivo(rs.getInt("progressivo"));
		gestioneDatiDelRapporto.setTipoDato(rs.getString("tipoDato"));
		gestioneDatiDelRapporto.setDescrizione(rs.getString("descrizione"));
		gestioneDatiDelRapporto.setDataRiferimento(rs.getDate("dataRiferimento"));
		gestioneDatiDelRapporto.setNoteVarie(rs.getString("noteVarie"));
		gestioneDatiDelRapporto.setDataCensimento(rs.getDate("dataCensimento"));
		gestioneDatiDelRapporto.setDataOra(rs.getDate("dataOra"));
		gestioneDatiDelRapporto.setId_ndg_rap(rs.getInt("id_ndg_rap"));
		
		return gestioneDatiDelRapporto;
    }

}
