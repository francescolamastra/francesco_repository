package it.fides.intesa.dao;

import javax.sql.DataSource;

import it.fides.intesa.model.GestioneDatiComplementariDelRapporto;

public interface GestioneDatiComplementariDelRapportoDao {
public void setDataSource(DataSource ds);
	
	//metodi CRUD
	//crea
	public void create(GestioneDatiComplementariDelRapporto gestioneDatiComplementariDelRapporto);
	
	//leggi
	public GestioneDatiComplementariDelRapporto read(int idGestDatiComplRapp);
	
	//Aggiorna
	public void update(GestioneDatiComplementariDelRapporto gestioneDatiComplementariDelRapporto);
	
	//Elimina
	public void delete(int idGestDatiComplRapp);
}
