package it.fides.intesa.dao;

import javax.sql.DataSource;

import it.fides.intesa.model.GestioneDatiComplementariDellaControparte;

public interface GestioneDatiComplementariDellaControparteDao {
	
	
	public void setDataSource(DataSource ds);
	
	//metodi CRUD
	//crea
	public void create(GestioneDatiComplementariDellaControparte gestioneDatiComplementariDellaControparte);
	
	//leggi
	public GestioneDatiComplementariDellaControparte read(int idGestDatiCompl);
	
	//Aggiorna
	public void update(GestioneDatiComplementariDellaControparte gestioneDatiComplementariDellaControparte);
	
	//Elimina
	public void delete(int idGestDatiCompl);
}
