package it.fides.intesa.dao;

import java.util.List;

import javax.sql.DataSource;

import it.fides.intesa.model.GestioneCodiciDellaControparte;
import it.fides.intesa.model.GestioneSettorizzazione;

public interface GestioneCodiciDellaControparteDao {
	
	public void setDataSource(DataSource ds);
	
	public void create(GestioneCodiciDellaControparte gestioneCodiciDellaControparteDao);
	public void update(GestioneCodiciDellaControparte gestioneCodiciDellaControparteDao);
	public void delete(int idGestioneCodiciDellaControparte);
	public GestioneCodiciDellaControparte read(int idGestioneCodiciDellaControparte);
	public List<GestioneCodiciDellaControparte> selectAll();
}