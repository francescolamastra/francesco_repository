package it.fides.intesa.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Time;
public class GestioneCodiciDellaControparte {
	
	private int idGestioneCodiciControparte;
	private String codice;
	private Date dataRiferimento;
	private int valoreCodice;
	private String descrizione;
	private String principaleCodice;
	private String forzatoCodice;
	private Date dataCensimento;
	private Time dataVaOraVa;
	private int idndg_codici;
	
	public GestioneCodiciDellaControparte() {}

	public int getIdGestioneCodiciControparte() {
		return idGestioneCodiciControparte;
	}

	public String getCodice() {
		return codice;
	}

	public Date getDataRiferimento() {
		return dataRiferimento;
	}

	public int getValoreCodice() {
		return valoreCodice;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public String getForzatoCodice() {
		return forzatoCodice;
	}

	public Date getDataCensimento() {
		return dataCensimento;
	}

	public Time getDataVaOraVa() {
		return dataVaOraVa;
	}

	public int getIdndg_codici() {
		return idndg_codici;
	}

	public void setIdGestioneCodiciControparte(int idGestioneCodiciControparte) {
		this.idGestioneCodiciControparte = idGestioneCodiciControparte;
	}

	public void setCodice(String codice) {
		this.codice = codice;
	}

	public void setDataRiferimento(Date dataRiferimento) {
		this.dataRiferimento = dataRiferimento;
	}

	public void setValoreCodice(int valoreCodice) {
		this.valoreCodice = valoreCodice;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public void setForzatoCodice(String forzatoCodice) {
		this.forzatoCodice = forzatoCodice;
	}

	public void setDataCensimento(Date dataCensimento) {
		this.dataCensimento = dataCensimento;
	}

	public void setDataVaOraVa(Time dataVaOraVa) {
		this.dataVaOraVa = dataVaOraVa;
	}

	public void setIdndg_codici(int idndg_codici) {
		this.idndg_codici = idndg_codici;
	}

	public String getPrincipaleCodice() {
		return principaleCodice;
	}

	public void setPrincipaleCodice(String principaleCodice) {
		this.principaleCodice = principaleCodice;
	};
	
	

}
