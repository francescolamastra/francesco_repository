package it.fides.intesa.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import it.fides.intesa.dao.namedParameter.JdbcBancaDAO;
import it.fides.intesa.dao.namedParameter.JdbcGestioneCodiciDellaControparteDAO;
import it.fides.intesa.dao.namedParameter.JdbcGestioneDatiDellaControparteDAO;
import it.fides.intesa.dao.namedParameter.JdbcGestioneEspansioneInformativaDAO;
import it.fides.intesa.dao.namedParameter.JdbcGestioneSettorizzazioniDAO;
import it.fides.intesa.model.Banca;
import it.fides.intesa.model.GestioneCodiciDellaControparte;
import it.fides.intesa.model.GestioneDatiDellaControparte;
import it.fides.intesa.model.GestioneEspansioneInformativa;
import it.fides.intesa.model.GestioneSettorizzazione;

@RestController
public class RestControllerJson {


	@RequestMapping(value="/gestionesett/{id}", method = RequestMethod.GET )
	public GestioneSettorizzazione gestioneSettorizzazione(@PathVariable int id) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		// GestioneSettorizzazione gestioneSettorizzazione = new
		// GestioneSettorizzazione();
		JdbcGestioneSettorizzazioniDAO jdbcGestioneSettorizzazioneDAO = (JdbcGestioneSettorizzazioniDAO) context
				.getBean("gestSett");
		GestioneSettorizzazione gestSett1 = jdbcGestioneSettorizzazioneDAO.read(id);

		//return new GestioneSettorizzazione(1,"sett1","desc1","valsetteco1","desc1",new Date(2015, 12, 11),new Date(2015, 12, 11, 11, 10, 00),1);
		return gestSett1;
	}
	
	@RequestMapping(value="/gestionesett", method = RequestMethod.GET)
	public List<GestioneSettorizzazione> listgestioneSettorizzazione() {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		// GestioneSettorizzazione gestioneSettorizzazione = new
		// GestioneSettorizzazione();
		JdbcGestioneSettorizzazioniDAO jdbcGestioneSettorizzazioneDAO = (JdbcGestioneSettorizzazioniDAO) context
				.getBean("gestSett");
		List<GestioneSettorizzazione> gestSett1 = jdbcGestioneSettorizzazioneDAO.selectAll();

		//return new GestioneSettorizzazione(1,"sett1","desc1","valsetteco1","desc1",new Date(2015, 12, 11),new Date(2015, 12, 11, 11, 10, 00),1);
		return gestSett1;
	}
	
	@RequestMapping(value="/gestionesett", method = RequestMethod.POST )
	public void createGestioneSettorizzazione(@RequestBody GestioneSettorizzazione input) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		// GestioneSettorizzazione gestioneSettorizzazione = new
		// GestioneSettorizzazione();
		JdbcGestioneSettorizzazioniDAO jdbcGestioneSettorizzazioneDAO = (JdbcGestioneSettorizzazioniDAO) context
				.getBean("gestSett");
		jdbcGestioneSettorizzazioneDAO.create(input);

		//return new GestioneSettorizzazione(1,"sett1","desc1","valsetteco1","desc1",new Date(2015, 12, 11),new Date(2015, 12, 11, 11, 10, 00),1);
		
	}
	
	@RequestMapping(value="/gestbanca", method = RequestMethod.GET)
	public List<Banca> listBanca() {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcBancaDAO jdbcBancaDAO = (JdbcBancaDAO) context
				.getBean("banca");
		List<Banca> banca = jdbcBancaDAO.read();

		return banca;
	}
	
	@RequestMapping(value="/gestionecodici/{id}", method = RequestMethod.GET )
	public GestioneCodiciDellaControparte gestioneCodiciDellaControparte(@PathVariable int id) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneCodiciDellaControparteDAO codiciDellaControparteDAO = (JdbcGestioneCodiciDellaControparteDAO) context
				.getBean("gestCodiciControparte");
		GestioneCodiciDellaControparte gestCodici1 = codiciDellaControparteDAO.read(id);

		return gestCodici1;
	}
	
	@RequestMapping(value="/gestionecodici", method = RequestMethod.GET)
	public List<GestioneCodiciDellaControparte> codiciDellaControparte() {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		
		JdbcGestioneCodiciDellaControparteDAO jdbcGestioneCodiciDellaControparteDAO = (JdbcGestioneCodiciDellaControparteDAO) context
				.getBean("gestCodiciControparte");
		List<GestioneCodiciDellaControparte> gestCodici1 = jdbcGestioneCodiciDellaControparteDAO.selectAll();

		return gestCodici1;
	}
	
	@RequestMapping(value="/gestionecodici", method = RequestMethod.POST )
	public void createGestioneCodici(@RequestBody GestioneCodiciDellaControparte input) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneCodiciDellaControparteDAO jdbcGestioneCodiciDellaControparteDAO = (JdbcGestioneCodiciDellaControparteDAO) context
				.getBean("gestCodiciControparte");
		jdbcGestioneCodiciDellaControparteDAO.create(input);
		
	}
	
	@RequestMapping(value="/gestespinf/{id}", method = RequestMethod.GET )
	public List<GestioneEspansioneInformativa> gestEspInfByNdg(@PathVariable int id) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneEspansioneInformativaDAO jdbcGestEspInfDAO = (JdbcGestioneEspansioneInformativaDAO) context
				.getBean("gestEspInf");
		List<GestioneEspansioneInformativa> gestEsp = jdbcGestEspInfDAO.selectAllByNdg(id);
		System.out.println(id);
		
		return gestEsp;
	}
	
	
	
	@RequestMapping(value="/gestespinf", method = RequestMethod.GET)
	public List<GestioneEspansioneInformativa> listgestEspInf() {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		
		JdbcGestioneEspansioneInformativaDAO jdbcGestEspInfDAO = (JdbcGestioneEspansioneInformativaDAO) context
				.getBean("gestEspInf");
		List<GestioneEspansioneInformativa> gestEsp = jdbcGestEspInfDAO.selectAll();

		
		return gestEsp;
	}

	@RequestMapping(value="/gestespinf", method = RequestMethod.POST )
	public void createGestEspInf(@RequestBody GestioneEspansioneInformativa input) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneEspansioneInformativaDAO jdbcGestEspInfDAO = (JdbcGestioneEspansioneInformativaDAO) context
				.getBean("gestEspInf");
		jdbcGestEspInfDAO.create(input);		
		
	}

	@RequestMapping(value="/gestespinf", method = RequestMethod.PUT )
	public void updateGestEspInf(@RequestBody GestioneEspansioneInformativa input) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneEspansioneInformativaDAO jdbcGestEspInfDAO = (JdbcGestioneEspansioneInformativaDAO) context
				.getBean("gestEspInf");
		jdbcGestEspInfDAO.update(input);	
		System.out.println("Aggiornato record con : " + input);	
		
	}


	@RequestMapping(value="/gestespinf/{id}", method = RequestMethod.DELETE )
	public void gestEspInfDel(@PathVariable int id) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneEspansioneInformativaDAO jdbcGestEspInfDAO = (JdbcGestioneEspansioneInformativaDAO) context
				.getBean("gestEspInf");
		jdbcGestEspInfDAO.delete(id);
		System.out.println("Cancellato record con id : " + id);
		
		
	}
	
	@RequestMapping(value="/gestdaticontroparte/{id}", method = RequestMethod.GET )
	public GestioneDatiDellaControparte gestioneDatiDellaControparte(@PathVariable int id) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneDatiDellaControparteDAO jdbcGestioneDatiDellaControparteDAO = (JdbcGestioneDatiDellaControparteDAO) context
				.getBean("gestDatiControparte");
		GestioneDatiDellaControparte gestDati1 = jdbcGestioneDatiDellaControparteDAO.read(id);

		return gestDati1;
	}
	
	@RequestMapping(value="/gestdaticontroparte", method = RequestMethod.GET)
	public List<GestioneDatiDellaControparte> listgestioneDatiDellaControparte() {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneDatiDellaControparteDAO jdbcGestioneDatiDellaControparteDAO = (JdbcGestioneDatiDellaControparteDAO) context
				.getBean("gestDatiControparte");
		List<GestioneDatiDellaControparte> gestDati1 = jdbcGestioneDatiDellaControparteDAO.selectAll();

		return gestDati1;
	}
	
	@RequestMapping(value="/gestdaticontroparte", method = RequestMethod.POST )
	public void createGestioneDatiDellaControparte(@RequestBody GestioneDatiDellaControparte input) {
		ApplicationContext context = new ClassPathXmlApplicationContext("WEB-INF/rest-servlet.xml");
		
		JdbcGestioneDatiDellaControparteDAO jdbcGestioneDatiDellaControparteDAO = (JdbcGestioneDatiDellaControparteDAO) context
				.getBean("gestDatiControparte");
		jdbcGestioneDatiDellaControparteDAO.create(input);		
	}
	
	@RequestMapping(value="/", method = RequestMethod.GET)
	public ModelAndView index(ModelAndView model) {
		model.setViewName("index");
		return model;
	}
}

