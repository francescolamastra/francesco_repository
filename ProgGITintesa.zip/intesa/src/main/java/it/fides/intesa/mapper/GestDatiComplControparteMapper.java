package it.fides.intesa.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import it.fides.intesa.model.GestioneDatiComplementariDellaControparte;

public class GestDatiComplControparteMapper implements RowMapper<GestioneDatiComplementariDellaControparte>{
	public GestioneDatiComplementariDellaControparte mapRow(ResultSet rs, int rowNum) throws SQLException {
		 
		GestioneDatiComplementariDellaControparte gesComplControparte = new GestioneDatiComplementariDellaControparte();
 
		gesComplControparte.setIdGestDatiCompl(rs.getInt("idGestDatiCompl"));
		gesComplControparte.setDatoComplementare(rs.getInt("datoComplementare"));
		gesComplControparte.setDescrizioneDato(rs.getString("descrizioneDato"));
		gesComplControparte.setValoreCodice(rs.getInt("valoreCodice"));
		gesComplControparte.setDescrizioneCodice(rs.getString("descrizioneCodice"));
		gesComplControparte.setId_ndg_dati_complementari(rs.getInt("id_ndg_dati_complementari"));
		
		return gesComplControparte;
    }

}
