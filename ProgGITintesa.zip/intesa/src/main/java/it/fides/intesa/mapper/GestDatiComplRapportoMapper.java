package it.fides.intesa.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import it.fides.intesa.model.GestioneDatiComplementariDelRapporto;

public class GestDatiComplRapportoMapper implements RowMapper<GestioneDatiComplementariDelRapporto>{
	public GestioneDatiComplementariDelRapporto mapRow(ResultSet rs, int rowNum) throws SQLException {
		 
		GestioneDatiComplementariDelRapporto gestioneDatiComplementariDelRapporto = new GestioneDatiComplementariDelRapporto();
 
		gestioneDatiComplementariDelRapporto.setIdGestDatiComplRapp(rs.getInt("idGestDatiComplRapp"));
		gestioneDatiComplementariDelRapporto.setDatoComplementare(rs.getString("datoComplementare"));
		gestioneDatiComplementariDelRapporto.setDescrizioneDato(rs.getString("descrizioneDato"));
		gestioneDatiComplementariDelRapporto.setValoreCodice(rs.getInt("valoreCodice"));
		gestioneDatiComplementariDelRapporto.setDescrizioneCodice(rs.getString("descrizioneCodice"));
		gestioneDatiComplementariDelRapporto.setId_ndg_dati_comp_rapp(rs.getInt("id_ndg_dati_comp_rapp"));
		
		
		return gestioneDatiComplementariDelRapporto;
    }
}
