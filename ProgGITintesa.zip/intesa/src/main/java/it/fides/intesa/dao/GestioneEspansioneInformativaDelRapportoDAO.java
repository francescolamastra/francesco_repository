package it.fides.intesa.dao;

import javax.sql.DataSource;

import it.fides.intesa.model.GestioneEspansioneInformativaDelRapporto;

public interface GestioneEspansioneInformativaDelRapportoDAO {

	public void setDataSource(DataSource ds);

	public void create(GestioneEspansioneInformativaDelRapporto gestioneEspansioneInformativaDelRapporto);

	public GestioneEspansioneInformativaDelRapporto read(int idGestEspInfDelRapp);

	public void update(GestioneEspansioneInformativaDelRapporto gestioneEspansioneInformativaDelRapporto);

	public void delete(int idGestEspInfDelRapp);

}
