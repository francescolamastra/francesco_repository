package it.fides.intesa.dao.namedParameter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;
import it.fides.intesa.dao.GestioneSettorizzazioneDao;
import it.fides.intesa.mapper.GestEspInfMapper;
import it.fides.intesa.mapper.GestSettMapper;
import it.fides.intesa.model.GestioneEspansioneInformativa;
import it.fides.intesa.model.GestioneSettorizzazione;


@Component
public class JdbcGestioneSettorizzazioniDAO implements GestioneSettorizzazioneDao {

private NamedParameterJdbcTemplate jdbcTemplateObject;
	
	public void setDataSource(DataSource dataSource) {
        this.jdbcTemplateObject = new NamedParameterJdbcTemplate(dataSource);
    }

	public void create (GestioneSettorizzazione gestioneSettorizzazione) {
		String SQL1 = "insert into gestionesettorizzazione (  settore, descrizione, valoreSettoreEco, descrizioneValore, dataCensimento, dataOra,idndg_set) "
				+ "values ( :settore,:descrizione,:valoreSettoreEco,:descrizioneValore,  :dataCensimento, :dataOra,:idndg_set)";
		
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneSettorizzazione);
        // Esegue la query passandogli anche i valori effettivi da inserire:
        jdbcTemplateObject.update(SQL1, namedParameters);
	}

	public GestioneSettorizzazione read(int idGestioneSettorizzazione) {
		final String SQL = "SELECT * FROM gestionesettorizzazione WHERE idGestioneSettorizzazione = :idGestioneSettorizzazione";

		SqlParameterSource namedParameters = new MapSqlParameterSource("idGestioneSettorizzazione", idGestioneSettorizzazione);

		return jdbcTemplateObject.queryForObject(SQL, namedParameters, new GestioneSettorizzazioneRowMapper());
	}
	
private static final class GestioneSettorizzazioneRowMapper implements RowMapper<GestioneSettorizzazione> {
		
		public GestioneSettorizzazione mapRow(ResultSet rs, int rowNum) throws SQLException {
			GestioneSettorizzazione gs = new GestioneSettorizzazione();
			gs.setIdGestioneSettorizzazione(rs.getInt("idGestioneSettorizzazione"));
			gs.setSettore(rs.getString("settore"));	
			gs.setDescrizione(rs.getString("descrizione"));
			gs.setValoreSettoreEco(rs.getString("valoreSettoreEco"));
			gs.setDescrizioneValore(rs.getString("descrizioneValore"));
			gs.setDataCensimento(rs.getDate("dataCensimento"));
			gs.setDataOra(rs.getDate("dataOra"));
			gs.setIdndg_set(rs.getInt("idndg_set"));
			
			return gs;
		}
	}

	public void update(GestioneSettorizzazione gestioneSettorizzazione) {
		final String SQL = "UPDATE gestionesettorizzazione SET " + 
						   "settore = :settore, descrizione = :descrizione, " +
						   "valoreSettoreEco = :valoreSettoreEco, descrizioneValore = :descrizioneValore, dataCensimento = :dataCensimento, " +
						   "dataOra = :dataOra, idndg_set = :idndg_set " +
						   "WHERE idGestioneSettorizzazione = :idGestioneSettorizzazione";
		
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneSettorizzazione);
		
		jdbcTemplateObject.update(SQL, namedParameters);
	}

	public void delete(int idGestioneSettorizzazione) {
		final String SQL = "DELETE FROM gestionesettorizzazione WHERE idGestioneSettorizzazione = :idGestioneSettorizzazione";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("idGestioneSettorizzazione", idGestioneSettorizzazione);
		
		jdbcTemplateObject.update(SQL, namedParameters);
		
		System.out.println(String.format("Record ID=%d eliminato", idGestioneSettorizzazione));
	}

	public List<GestioneSettorizzazione> selectAll() {
		String SQL = "select * from gestionesettorizzazione";
		
		List<GestioneSettorizzazione> gestioneSettorizzazione = jdbcTemplateObject.query(SQL, new GestSettMapper());
			return gestioneSettorizzazione;
	}
	
	
}
