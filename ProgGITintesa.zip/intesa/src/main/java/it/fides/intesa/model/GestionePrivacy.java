package it.fides.intesa.model;

public class GestionePrivacy {
	private int id_gestprivacy;
	private String tipoPrivacy;
	private String descrizionePrivacy;
	private String consenso;
	private String invInformativa;
	private String sportelloRif;
	private String descrizioneSportelloRif;
	private String riferimento;
	private String note;
	private String linkDocumento;
	private int id_ndg_privacy;
	
	public int getId_gestprivacy() {
		return id_gestprivacy;
	}
	public void setId_gestprivacy(int id_gestprivacy) {
		this.id_gestprivacy = id_gestprivacy;
	}
	public String getTipoPrivacy() {
		return tipoPrivacy;
	}
	public void setTipoPrivacy(String tipoPrivacy) {
		this.tipoPrivacy = tipoPrivacy;
	}
	public String getDescrizionePrivacy() {
		return descrizionePrivacy;
	}
	public void setDescrizionePrivacy(String descrizionePrivacy) {
		this.descrizionePrivacy = descrizionePrivacy;
	}
	public String getConsenso() {
		return consenso;
	}
	public void setConsenso(String consenso) {
		this.consenso = consenso;
	}
	public String getInvInformativa() {
		return invInformativa;
	}
	public void setInvInformativa(String invInformativa) {
		this.invInformativa = invInformativa;
	}
	public String getSportelloRif() {
		return sportelloRif;
	}
	public void setSportelloRif(String sportelloRif) {
		this.sportelloRif = sportelloRif;
	}
	public String getDescrizioneSportelloRif() {
		return descrizioneSportelloRif;
	}
	public void setDescrizioneSportelloRif(String descrizioneSportelloRif) {
		this.descrizioneSportelloRif = descrizioneSportelloRif;
	}
	public String getRiferimento() {
		return riferimento;
	}
	public void setRiferimento(String riferimento) {
		this.riferimento = riferimento;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getLinkDocumento() {
		return linkDocumento;
	}
	public void setLinkDocumento(String linkDocumento) {
		this.linkDocumento = linkDocumento;
	}
	public int getId_ndg_privacy() {
		return id_ndg_privacy;
	}
	public void setId_ndg_privacy(int id_ndg_privacy) {
		this.id_ndg_privacy = id_ndg_privacy;
	}
}
