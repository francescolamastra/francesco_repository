package it.fides.intesa.dao.namedParameter;

import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import it.fides.intesa.dao.GestioneDatiComplementariDelRapportoDao;
import it.fides.intesa.dao.GestioneDatiComplementariDellaControparteDao;
import it.fides.intesa.mapper.GestDatiComplControparteMapper;
import it.fides.intesa.mapper.GestDatiComplRapportoMapper;
import it.fides.intesa.model.GestioneDatiComplementariDelRapporto;
import it.fides.intesa.model.GestioneDatiComplementariDellaControparte;
@Component
public class JdbcGestioneDatiComplementariDelRapportoDAO implements GestioneDatiComplementariDelRapportoDao{
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	   
	   
	 public void setDataSource(DataSource dataSource) {
	      this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	   }
	
	 //metodi CRUD
	//crea
	public void create(GestioneDatiComplementariDelRapporto gestioneDatiComplementariDelRapporto) {
		final String SQL = "INSERT INTO gestionedaticomplementaridelrapporto" +
							"(idGestDatiComplRapp, datoComplementare, descrizioneDato, valoreCodice, descrizioneCodice, id_ndg_dati_comp_rapp)" +
							"VALUES " +
							"(:idGestDatiComplRapp, :datoComplementare, :descrizioneDato, :valoreCodice, :descrizioneCodice, :id_ndg_dati_comp_rapp)"; 

		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneDatiComplementariDelRapporto);
		
		namedParameterJdbcTemplate.update(SQL, namedParameters);
		}
	
	//leggi
	public GestioneDatiComplementariDelRapporto read(int idGestDatiComplRapp) {
		final String SQL = "SELECT * FROM gestionedaticomplementaridelrapporto WHERE idGestDatiComplRapp = :idGestDatiComplRapp";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("idGestDatiComplRapp", idGestDatiComplRapp);
		
		return namedParameterJdbcTemplate.queryForObject(SQL, namedParameters, new GestDatiComplRapportoMapper());
	}
	
	//modifica
	public void update(GestioneDatiComplementariDelRapporto gestioneDatiComplementariDelRapporto) {
		
		final String SQL = "UPDATE gestionedaticomplementaridelrapporto SET" +
				   "idGestDatiComplRapp = :idGestDatiComplRapp, datoComplementare = :datoComplementare, descrizioneDato = :descrizioneDato, valoreCodice = :valoreCodice, descrizioneCodice = :descrizioneCodice, id_ndg_dati_comp_rapp = :id_ndg_dati_comp_rapp";
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneDatiComplementariDelRapporto);
		
		namedParameterJdbcTemplate.update(SQL, namedParameters);
		
	}

	public void delete(int idGestDatiComplRapp) {
		
		final String SQL = "DELETE FROM gestionedaticomplementaridelrapporto WHERE idGestDatiComplRapp = :idGestDatiComplRapp";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("idGestDatiComplRapp", idGestDatiComplRapp);
		
	}	
}
