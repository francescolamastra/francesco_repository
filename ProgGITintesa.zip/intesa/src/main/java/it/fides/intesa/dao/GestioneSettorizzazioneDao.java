package it.fides.intesa.dao;

import java.util.List;

import javax.sql.DataSource;

import it.fides.intesa.model.GestioneSettorizzazione;

public interface GestioneSettorizzazioneDao {
	
	public void setDataSource(DataSource ds);
	
	public void create(GestioneSettorizzazione gestioneSettorizzazione);

//	public GestioneSettorizzazione read(int idGestioneSettorizzazione);
//
//	public void update(GestioneSettorizzazione gestioneSettorizzazione);
//
//	public void delete(int idGestioneSettorizzazione);

	public List<GestioneSettorizzazione> selectAll();
}
