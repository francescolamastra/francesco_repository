package it.fides.intesa.dao.namedParameter;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import it.fides.intesa.dao.BancaDao;
import it.fides.intesa.mapper.BancaMapper;
import it.fides.intesa.mapper.GestCodiciDellaControparteMapper;
import it.fides.intesa.model.Banca;

@Component
public class JdbcBancaDAO implements BancaDao {

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
	      this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	   }

	

	@Override
	public List<Banca> read() {
		final String SQL = "SELECT * FROM banca";
		
		List<Banca> banca = namedParameterJdbcTemplate.query(SQL, new BancaMapper());
		return banca;
	}
}