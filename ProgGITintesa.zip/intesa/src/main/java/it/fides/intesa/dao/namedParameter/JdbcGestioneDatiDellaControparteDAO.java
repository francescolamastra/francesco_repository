package it.fides.intesa.dao.namedParameter;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import it.fides.intesa.dao.GestioneDatiDellaControparteDao;
import it.fides.intesa.mapper.GestDatiControparteMapper;
import it.fides.intesa.model.GestioneDatiDellaControparte;

@Component
public class JdbcGestioneDatiDellaControparteDAO implements GestioneDatiDellaControparteDao {
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	   
	   
	 public void setDataSource(DataSource dataSource) {
	      this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	   }
	
	//metodi CRUD
	//crea
	public void create(GestioneDatiDellaControparte gestioneDatiDellaControparte) {
		final String SQL = "INSERT INTO gestionedatidellacontroparte" +
						   "(tipoDato, progressivo, noteVarie, descrizione, dataOra, dataRiferimento, dataCensimento, idndg_dati)"+
						   "VALUES " +
						   "(:tipoDato, :progressivo, :noteVarie, :descrizione, :dataOra, :dataRiferimento, :dataCensimento, :idndg_dati)";
		
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneDatiDellaControparte);
		
		namedParameterJdbcTemplate.update(SQL, namedParameters);
		}
	
	//leggi
	public GestioneDatiDellaControparte read(int idGestioneDatiDellaControparte) {
		final String SQL = "SELECT * FROM gestionedatidellacontroparte WHERE idGestioneDatiDellaControparte = :idGestioneDatiDellaControparte";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("idGestioneDatiDellaControparte", idGestioneDatiDellaControparte);
		
		return namedParameterJdbcTemplate.queryForObject(SQL, namedParameters, new GestDatiControparteMapper());
	}
	
	//modifica
	public void update(GestioneDatiDellaControparte gestioneDatiDellaControparte) {
		final String SQL = "UPDATE gestionedatidellacontroparte SET" +
						   "idGestioneDatiDellaControparte = :idGestioneDatiDellaControparte, tipoDato = :tipoDato, progressivo = :progressivo, "
						   + "noteVarie = :noteVarie, descrizione= :descrizione, dataOra = :dataOra, dataRiferimento = :dataRiferimento, "
						   + "dataCensimento = :dataCensimento, idndg_dati = :idndg_dati";
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneDatiDellaControparte);
		
		namedParameterJdbcTemplate.update(SQL, namedParameters);
	}
	//cancella
	public void delete(int idGestioneDatiDellaControparte) {
		final String SQL = "DELETE FROM gestionedatidellacontroparte WHERE idGestioneDatiDellaControparte = :idGestioneDatiDellaControparte";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("idGestioneDatiDellaControparte", idGestioneDatiDellaControparte);
		
	}
	//lista
	public List<GestioneDatiDellaControparte> selectAll() {
		String SQL = "select * from gestionedatidellacontroparte";
		
		List<GestioneDatiDellaControparte> gestioneDatiDellaControparte = namedParameterJdbcTemplate.query(SQL, new GestDatiControparteMapper());
			return gestioneDatiDellaControparte;
	}
}
