package it.fides.intesa.dao.namedParameter;

import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import it.fides.intesa.dao.GestioneDatiComplementariDellaControparteDao;
import it.fides.intesa.mapper.GestDatiComplControparteMapper;
import it.fides.intesa.model.GestioneDatiComplementariDellaControparte;

@Component
public class JdbcGestioneDatiComplementariDellaControparteDAO implements GestioneDatiComplementariDellaControparteDao{
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	   
	   
	 public void setDataSource(DataSource dataSource) {
	      this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	   }
	
	 //metodi CRUD
	//crea
	public void create(GestioneDatiComplementariDellaControparte gestioneDatiComplementariDellaControparte) {
		final String SQL = "INSERT INTO gestionedaticomplementaridellacontroparte" +
							"(idGestDatiCompl, datoComplementare, descrizioneDato, valoreCodice, descrizioneCodice, id_ndg_dati_complementari)" +
							"VALUES " +
							"(:idGestDatiCompl, :datoComplementare, :descrizioneDato, :valoreCodice, :descrizioneCodice, :id_ndg_dati_complementari)"; 

		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneDatiComplementariDellaControparte);
		
		namedParameterJdbcTemplate.update(SQL, namedParameters);
		}
	
	//leggi
	public GestioneDatiComplementariDellaControparte read(int idGestDatiCompl) {
		
		final String SQL = "SELECT * FROM gestionedaticomplementaridellacontroparte WHERE idGestDatiCompl = :idGestDatiCompl";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("idGestDatiCompl", idGestDatiCompl);
		
		return namedParameterJdbcTemplate.queryForObject(SQL, namedParameters, new GestDatiComplControparteMapper());
	}
	
	//modifica
	public void update(GestioneDatiComplementariDellaControparte gestioneDatiComplementariDellaControparte) {
		
		final String SQL = "UPDATE gestionedaticomplementaridellacontroparte SET" +
				   "idGestDatiCompl = :idGestDatiCompl, datoComplementare = :datoComplementare, descrizioneDato = :descrizioneDato, valoreCodice = :valoreCodice, descrizioneCodice = :descrizioneCodice, id_ndg_dati_complementari = :id_ndg_dati_complementari";
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneDatiComplementariDellaControparte);
		
		namedParameterJdbcTemplate.update(SQL, namedParameters);
		
	}
	//cancella
	public void delete(int idGestDatiCompl) {
		
		final String SQL = "DELETE FROM gestionedaticomplementaridellacontroparte WHERE idGestDatiCompl = :idGestDatiCompl";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("idGestDatiCompl", idGestDatiCompl);
		}
}
