package it.fides.intesa.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import it.fides.intesa.model.GestionePrivacy;

public class GestionePrivacyMapper implements RowMapper<GestionePrivacy>{
	public GestionePrivacy mapRow(ResultSet rs, int rowNum) throws SQLException {
		 
		GestionePrivacy gestPrivacy = new GestionePrivacy();
 
        gestPrivacy.setId_gestprivacy(rs.getInt("id_gestprivacy"));
        gestPrivacy.setTipoPrivacy(rs.getString("tipoPrivacy"));
        gestPrivacy.setDescrizionePrivacy(rs.getString("descrizionePrivacy"));
        gestPrivacy.setConsenso(rs.getString("consenso"));
        gestPrivacy.setInvInformativa(rs.getString("invInformativa"));
        gestPrivacy.setSportelloRif(rs.getString("sportelloRif"));
        gestPrivacy.setDescrizioneSportelloRif(rs.getString("descrizioneSportelloRif"));
        gestPrivacy.setRiferimento(rs.getString("riferimento"));
        gestPrivacy.setNote(rs.getString("note"));
        gestPrivacy.setLinkDocumento(rs.getString("linkDocumento"));
        gestPrivacy.setId_ndg_privacy(rs.getInt("id_ndg_privacy"));
       
 
        return gestPrivacy;
    }

}
