package it.fides.intesa.dao.namedParameter;

import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import it.fides.intesa.dao.GestioneDatiDelRapportoDao;
import it.fides.intesa.mapper.GestDatiRapportoMapper;
import it.fides.intesa.model.GestioneDatiDelRapporto;

@Component
public class JdbcGestioneDatiDelRapportoDAO implements GestioneDatiDelRapportoDao {
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	   
	   
	 public void setDataSource(DataSource dataSource) {
	      this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	   }
	
	//metodi CRUD
	//crea
	public void create(GestioneDatiDelRapporto gestioneDatiDelRapporto) {
		final String SQL = "INSERT INTO gestionedatidelrapporto" +
						   "(progressivo, tipoDato, descrizione, dataRiferimento, noteVarie, dataCensimento, dataOra, id_ndg_rap)"+
						   "VALUES " +
						   "(:progressivo, :tipoDato, :descrizione,:dataRiferimento, :noteVarie, :dataCensimento, :dataOra, :id_ndg_rap)";
		
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneDatiDelRapporto);
		
		namedParameterJdbcTemplate.update(SQL, namedParameters);
		}
	
	//leggi
	public GestioneDatiDelRapporto read(int progressivo) {
		final String SQL = "SELECT * FROM gestionedatidelrapporto WHERE progressivo = :progressivo";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("progressivo", progressivo);
		
		return namedParameterJdbcTemplate.queryForObject(SQL, namedParameters, new GestDatiRapportoMapper());
	}
	
	//modifica
	public void update(GestioneDatiDelRapporto gestioneDatiDelRapporto) {
		final String SQL = "UPDATE gestionedatidelrapporto SET" +
						   "progressivo = :progressivo, tipoDato = :tipoDato, descrizione = :descrizione, dataRiferimento = :dataRiferimento, noteVarie = :noteVarie, dataCensimento = :dataCensimento, dataOra = :dataOra, id_ndg_rap = :id_ndg_rap";
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(gestioneDatiDelRapporto);
		
		namedParameterJdbcTemplate.update(SQL, namedParameters);
	}
	//cancella
	public void delete(int progressivo) {
		final String SQL = "DELETE FROM gestionedatidelrapporto WHERE progressivo = :progressivo";
		
		SqlParameterSource namedParameters = new MapSqlParameterSource("progressivo", progressivo);
		
	}
}
