package it.fides.intesa.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import it.fides.intesa.model.GestioneEspansioneInformativa;
import it.fides.intesa.model.GestioneSettorizzazione;

public class GestSettMapper implements RowMapper<GestioneSettorizzazione>{
	public GestioneSettorizzazione mapRow(ResultSet rs, int rowNum) throws SQLException {
		 
		GestioneSettorizzazione gestioneSettorizzazione = new GestioneSettorizzazione();
 
		gestioneSettorizzazione.setSettore(rs.getString("settore"));
		gestioneSettorizzazione.setDescrizione(rs.getString("descrizione"));
		gestioneSettorizzazione.setValoreSettoreEco(rs.getString("valoreSettoreEco"));
		gestioneSettorizzazione.setDescrizioneValore(rs.getString("descrizioneValore"));
		gestioneSettorizzazione.setDataCensimento(rs.getDate("dataCensimento"));
		gestioneSettorizzazione.setDataOra(rs.getTime("dataOra"));
		gestioneSettorizzazione.setIdGestioneSettorizzazione(rs.getInt("idGestioneSettorizzazione"));
		gestioneSettorizzazione.setIdndg_set(rs.getInt("idndg_set"));
 
        return gestioneSettorizzazione;
    }

}
