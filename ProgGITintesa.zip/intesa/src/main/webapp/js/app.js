(function(angular){
	'use strict';
	
	angular.module('appModule', ['ui.bootstrap', 'ui.router']);
})(window.angular);
