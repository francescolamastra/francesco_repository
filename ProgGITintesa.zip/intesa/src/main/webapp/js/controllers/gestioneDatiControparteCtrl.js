angular.module('appModule')
.controller('gestioneDatiControparteCtrl', ['$http', '$uibModal', function($http, $uibModal) {
	var ctrl = this;
	$http.get('http://localhost:8080/intesa/gestdaticontroparte').
        then(function(response) {
            ctrl.rows = response.data;
        });
	
	ctrl.openCrea = function(tipoDato){
		var modalInstance = $uibModal.open({
			templateUrl: 'templates/modals/dettagliDatiControparte/creaDato.html',
            backdrop : 'static',
            keyboard : false,
            controller: 'datiModalCreaCtrl as vm',
            size : 'sm',
            resolve: {
            	modalTipoDato : function(){
            		return tipoDato;
            	}
            }            	
		});
	};
	
 	ctrl.selezionato = 10;
	ctrl.optionVal = [
		{
			"name":10
		},
		{
			"name":25
		},
		{
			"name":50
		},
		{
			"name":100
		}
	];
	
	ctrl.tipoDato = [
	 			  {
	 				  name: "tipo 0 - descrizione varia per tipo 0",
	 				  value: "00"
	 			  },
	 			  {
	 				  name: "tipo 1 - descrizione varia per tipo 1",
	 				  value: "01"
	 			  },
	 			  {
	 				  name: "tipo 2 - descrizione varia per tipo 2",
	 				  value: "02"
	 			  },
	 			  {
	 				  name: "tipo 3 - descrizione varia per tipo 3",
	 				  value: "03"
	 			  },
	 			  {
	 				  name: "tipo 4 - descrizione varia per tipo 4",
	 				  value: "04"
	 			  },
	 			  {
	 				  name: "tipo 5 - descrizione varia per tipo 5",
	 				  value: "05"
	 			  },
	 			  {
	 				  name: "tipo 6 - descrizione varia per tipo 6",
	 				  value: "06"
	 			  },
	 			  {
	 				  name: "tipo 7 - descrizione varia per tipo 7",
	 				  value: "07"
	 			  },
	 			  {
	 				  name: "tipo 8 - descrizione varia per tipo 8",
	 				  value: "08"
	 			  },
	 			  {
	 				  name: "tipo 9 - descrizione varia per tipo 9",
	 				  value: "09"
	 			  }
	 		  ];
	
	ctrl.selected=null;
    ctrl.select = function(prog) {
  	  ctrl.selected = prog;
    };
    
    ctrl.nuovo={
			  'datoV': null,
			  'dataRif': null,
			  'noteVarie': null, 
			  };
  /*  $http.post('http://localhost:8080/intesa/gestdaticontroparte', $scope.gestrecord ).then(function(success){
    	console.log('OK');
    }, function(error){
    	console.log('KO');
    });
    
    $http.update('http://localhost:8080/intesa/gestdaticontroparte/4').then(function(success){
    	console.log('OK');
    }, function(error){
    	console.log('KO');
    });*/
   
}]);

