angular.module('appModule')
.controller('gestioneCodiciControparteCtrl', ['$http', '$uibModal', function($http, $uibModal) {
	var ctrl = this;
    $http.get('http://localhost:8080/intesa/gestionecodici').
        then(function(response) {
            ctrl.rows = response.data;
        });
    ctrl.quantity = 10;
	ctrl.entries = [
		{
			"number":10
		},
		{
			"number":25
		},
		{
			"number":50
		},
		{
			"number":100
		}
	];
	ctrl.selectRow = function (row) {
		ctrl.selectedRow = row
	};
	ctrl.openDettaglio = function (selectedRow) {
        var modalInstance = $uibModal.open({
            templateUrl: 'templates/modals/gestioneCodici/dettaglioModal.html',
            controller: 'codiciModalDettaglioCtrl as vm',
            backdrop: 'static',
            keyboard: false,
            resolve: {
            	modalSelectedRow: function() {
            		return selectedRow;
            	}
            }
        });
    };
    ctrl.openNuovo = function () {
        var modalInstance = $uibModal.open({
            templateUrl: 'templates/modals/gestioneCodici/nuovoModal.html',
            controller: 'codiciModalNuovoCtrl as vm',
            backdrop: 'static',
            keyboard: false,
            })
        };
}]);