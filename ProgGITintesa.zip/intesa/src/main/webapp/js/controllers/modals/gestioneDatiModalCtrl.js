(function(angular) {
	'use strict';
	
	angular.module('appModule')
	.controller('datiModalCreaCtrl', ['$uibModalInstance', 'modalTipoDato',
	                                  function($uibModalInstance, modalTipoDato){
		var vm = this;
		 vm.close = function () {
	            $uibModalInstance.close();
	          };
	       vm.tipoDato = modalTipoDato;
	       
	       vm.nuovoTab = function(){
				  vm.rows.push({
				  'progressivo' : vm.tabella[vm.tabella.length-1].progressivo+1,
				  'datoV' : 'DA'+ vm.nuovo.datoV,
				  'dataRif' : vm.nuovo.dataRif,
				  'noteVarie' : vm.nuovo.noteVarie,
				  'descrizione' : 'Dati Vari Controparte'+vm.nuovo.datoV,
				  'dataCensimento' : '12/11/2016',
				  'dataOra' : '12/11/2016 - 12.00',
				  });  
				  $uibModalInstance.close();
				  
				  //INSTANZIAZIONE DEI DATI PASSATI
				  vm.nuovo.datoV = null;
				  vm.nuovo.dataRif=null;
				  vm.nuovo.noteVarie=null;
			  }
	}])
	
})(window.angular);