(function(angular){
	'use strict';
	angular.module('appModule')
	.controller('initialModalCtrl', ['$uibModalInstance', 'modalSelected', '$http',
	                                 function($uibModalInstance, modalSelected, $http){
		var vm = this;
		$http.get('http://localhost:8080/intesa/gestbanca').
        then(function(response) {
            vm.banche = response.data;
        });
		vm.selectedServizio = modalSelected;
		vm.close = function () {
        	$uibModalInstance.close();
        };
	}])
})(window.angular);