angular.module('appModule')
.controller('gestioneSettorizzazioneCtrl', function($scope, $http) {
    $http.get('http://localhost:8080/intesa/gestionesett').
        then(function(response) {
            $scope.gestioneSett = response.data;
        });
    $scope.gestrecord={
    		"idGestioneSettorizzazione":2,
    		"settore":"L10",
    		"descrizione":"Descrizione Settore L10",
    		"valoreSettoreEco":"Valore Settore L10",
    		"descrizioneValore":"Descrizione Valore Settore L10",
    		"dataCensimento":"2017-02-28",
    		"dataOra":"2017-02-28",
    		"idndg_set":1
    		};
    $http.post('http://localhost:8080/intesa/gestionesett', $scope.gestrecord ).then(function(success){
    	console.log('OK');
    }, function(error){
    	console.log('KO');
    });
});

